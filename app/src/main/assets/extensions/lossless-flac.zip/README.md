# Fonte de áudio integrada ao Shinyfly

Pacote interno. A instalação e a execução são gerenciadas pelo aplicativo.
Consulte a licença incluída neste pacote.
