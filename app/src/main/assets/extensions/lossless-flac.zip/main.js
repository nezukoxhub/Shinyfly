// ── 00-header.js ──
// Lossless FLAC for Myspoti (API v1)
// Multi-source Hi-Res / CD FLAC & 320k audio streaming and offline download extension.
// Runs inside Myspoti's Rhino 1.8.1 sandbox (`myspoti` global, synchronous I/O, no DOM/Node).
(function () {
  'use strict';

  var EXT_VERSION = '1.0.0';
  var DEFAULT_UA = 'LosslessFLAC-Myspoti/' + EXT_VERSION + ' (Android; Myspoti Extension API/1)';
  var STREAM_CACHE_MS = 180000;

  var BUDGET = {
    audio: 13200,
    ahead: 9500,
    download: 26500,
    trackinfo: 2200,
    page: 7500
  };

  var deadlineAt = 0;
  var aheadMode = false;
  var memStreamCache = {};
  var memCatalogCache = {};
  var recentStreamPick = {};

  function withBudget(ms, isAhead, fn) {
    var prevDeadline = deadlineAt;
    var prevAhead = aheadMode;
    deadlineAt = Date.now() + ms;
    aheadMode = !!isAhead;
    try {
      return fn();
    } finally {
      deadlineAt = prevDeadline;
      aheadMode = prevAhead;
    }
  }

  function timeLeft() {
    return deadlineAt ? deadlineAt - Date.now() : 30000;
  }

  function hasTime(minMs) {
    return timeLeft() >= (minMs || 1200);
  }

  function hostHas(feature) {
    var f = myspoti && myspoti.features;
    return !!(f && f.indexOf && f.indexOf(feature) >= 0);
  }

  function log(msg) {
    try {
      myspoti.log('[Lossless FLAC] ' + msg);
    } catch (e) {}
  }

  function appendDiag(kind, summary) {
    try {
      var list = myspoti.storage.get('diag.recent');
      if (!Array.isArray(list)) list = [];
      list.unshift({
        at: new Date().toISOString().substring(11, 19),
        kind: String(kind || 'info'),
        msg: String(summary || '').substring(0, 180)
      });
      if (list.length > 24) list.length = 24;
      myspoti.storage.set('diag.recent', list);
    } catch (e) {}
  }

  // ── Settings helpers ────────────────────────────────────────────────────────

  function rawSetting(key) {
    // The bundled source has no user-facing extension settings page.
    return undefined;
  }

  function settingStr(key, fallback) {
    var v = rawSetting(key);
    if (v === undefined || v === null) return fallback || '';
    var s = String(v).trim();
    return s === '' && fallback !== undefined ? fallback : s;
  }

  function settingBool(key, fallback) {
    var v = rawSetting(key);
    if (v === undefined || v === null || v === '') return !!fallback;
    if (typeof v === 'boolean') return v;
    var s = String(v).toLowerCase().trim();
    if (s === 'true' || s === '1' || s === 'yes') return true;
    if (s === 'false' || s === '0' || s === 'no') return false;
    return !!fallback;
  }

  function settingList(key, fallbackCsv) {
    var raw = settingStr(key, fallbackCsv || '');
    if (!raw) return [];
    var parts = raw.split(/[\s,;]+/);
    var out = [];
    var seen = {};
    for (var i = 0; i < parts.length; i++) {
      var item = parts[i].trim();
      if (!item) continue;
      var k = item.toLowerCase();
      if (!seen[k]) {
        seen[k] = true;
        out.push(item);
      }
    }
    return out;
  }

  function settingUrlList(key) {
    var raw = settingStr(key, '');
    if (!raw) return [];
    var parts = raw.split(/[\s,\n]+/);
    var out = [];
    var seen = {};
    for (var i = 0; i < parts.length; i++) {
      var u = stripSlash(parts[i].trim());
      if (!/^https:\/\//i.test(u)) continue;
      var k = u.toLowerCase();
      if (!seen[k]) {
        seen[k] = true;
        out.push(u);
      }
    }
    return out;
  }

  function stripSlash(u) {
    return String(u || '').replace(/\/+$/, '');
  }

  function enc(s) {
    return encodeURIComponent(String(s == null ? '' : s));
  }

  function escHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function decodeXmlEntities(s) {
    return String(s == null ? '' : s)
      .replace(/&amp;/g, '&')
      .replace(/&lt;/g, '<')
      .replace(/&gt;/g, '>')
      .replace(/&quot;/g, '"')
      .replace(/&apos;/g, "'")
      .replace(/&#(\d+);/g, function (_, dec) {
        var n = parseInt(dec, 10);
        return isNaN(n) ? _ : String.fromCharCode(n);
      })
      .replace(/&#x([0-9a-fA-F]+);/g, function (_, hex) {
        var n = parseInt(hex, 16);
        return isNaN(n) ? _ : String.fromCharCode(n);
      });
  }

  // ── Instance & Provider Health / Cooldown Book ─────────────────────────────
  // Soft cooldown: 60s (HTTP 429, transient timeout, 5xx)
  // Hard cooldown: 600s (HTTP 401/403, invalid instance, repeated failure)

  var SOFT_COOLDOWN_MS = 60000;
  var HARD_COOLDOWN_MS = 600000;

  function getCooldownMap() {
    var m = myspoti.storage.get('health.cooldowns');
    return m && typeof m === 'object' ? m : {};
  }

  function saveCooldownMap(m) {
    var now = Date.now();
    var cleaned = {};
    var keys = Object.keys(m);
    for (var i = 0; i < keys.length && i < 80; i++) {
      var k = keys[i];
      if (m[k] && m[k].until > now) cleaned[k] = m[k];
    }
    myspoti.storage.set('health.cooldowns', cleaned);
  }

  function isCooledDown(key) {
    var m = getCooldownMap();
    var entry = m[key];
    return !!(entry && entry.until > Date.now());
  }

  function markCooldown(key, durationMs, reason) {
    var m = getCooldownMap();
    m[key] = {
      until: Date.now() + Math.max(15000, Math.min(durationMs || SOFT_COOLDOWN_MS, 900000)),
      reason: String(reason || 'cooldown').substring(0, 80)
    };
    saveCooldownMap(m);
  }

  function clearCooldown(key) {
    var m = getCooldownMap();
    if (m[key]) {
      delete m[key];
      saveCooldownMap(m);
    }
  }

  function clearAllCachesAndCooldowns() {
    memStreamCache = {};
    memCatalogCache = {};
    recentStreamPick = {};
    myspoti.storage.remove('health.cooldowns');
    myspoti.storage.remove('cache.trackinfo');
    myspoti.storage.remove('pool.accounts');
    myspoti.storage.remove('pool.discovery');
    appendDiag('reset', 'Cache e cooldown azzerati');
  }

  // ── Safe HTTP Client with Budget Clamping & Parallel Batch Support ──────────

  function retryAfterMs(headers) {
    if (!headers) return 0;
    for (var k in headers) {
      if (Object.prototype.hasOwnProperty.call(headers, k) && String(k).toLowerCase() === 'retry-after') {
        var raw = String(headers[k] || '').trim();
        if (/^\d+(?:\.\d+)?$/.test(raw)) return Math.max(0, Math.round(Number(raw) * 1000));
        var at = Date.parse(raw);
        return isNaN(at) ? 0 : Math.max(0, at - Date.now());
      }
    }
    return 0;
  }

  function headerValue(headers, name) {
    if (!headers) return '';
    var target = String(name || '').toLowerCase();
    for (var k in headers) {
      if (Object.prototype.hasOwnProperty.call(headers, k) && String(k).toLowerCase() === target) {
        return String(headers[k] || '');
      }
    }
    return '';
  }

  function shapeHttpReply(r) {
    if (!r || r.error != null) {
      return {
        status: 0,
        ok: false,
        text: '',
        json: null,
        headers: {},
        error: r ? String(r.error) : 'request failed',
        retryAfter: 0
      };
    }
    var parsed = null;
    if (r.body && r.body.length < 4 * 1024 * 1024) {
      var trimmed = r.body.trim();
      if (trimmed.charAt(0) === '{' || trimmed.charAt(0) === '[') {
        try {
          parsed = JSON.parse(trimmed);
        } catch (e) {
          parsed = null;
        }
      }
    }
    return {
      status: r.status || 0,
      ok: !!r.ok,
      text: r.body || '',
      json: parsed,
      headers: r.headers || {},
      error: null,
      retryAfter: retryAfterMs(r.headers)
    };
  }

  function clampTimeout(requestedMs) {
    var want = requestedMs || 5000;
    var left = timeLeft();
    if (left < 1100) return 0;
    var maxSafe = Math.max(800, Math.floor((left - 350) / 2));
    return Math.min(want, maxSafe);
  }

  function buildHeaders(custom) {
    var h = {
      'Accept': 'application/json, text/plain, */*',
      'User-Agent': DEFAULT_UA
    };
    if (custom) {
      for (var k in custom) {
        if (Object.prototype.hasOwnProperty.call(custom, k) && custom[k] !== undefined && custom[k] !== null) {
          h[k] = String(custom[k]);
        }
      }
    }
    return h;
  }

  function httpCall(method, url, body, headers, timeoutMs) {
    var wait = clampTimeout(timeoutMs || 5000);
    if (!wait) {
      return { status: 0, ok: false, text: '', json: null, headers: {}, error: 'budget exhausted', retryAfter: 0 };
    }
    try {
      var resp = myspoti.http.request({
        url: url,
        method: method || 'GET',
        headers: buildHeaders(headers),
        body: body === undefined || body === null ? undefined : body,
        timeout: wait
      });
      return shapeHttpReply(resp);
    } catch (e) {
      return {
        status: 0,
        ok: false,
        text: '',
        json: null,
        headers: {},
        error: String(e && e.message ? e.message : e),
        retryAfter: 0
      };
    }
  }

  function httpGet(url, headers, timeoutMs) {
    return httpCall('GET', url, undefined, headers, timeoutMs);
  }

  function httpPost(url, body, headers, timeoutMs) {
    return httpCall('POST', url, body, headers, timeoutMs);
  }

  /**
   * Sends up to 4 requests concurrently using Myspoti's `http.all` (falls back to sequential).
   */
  function httpBatch(requests, timeoutMs) {
    if (!requests || !requests.length) return [];
    var wait = clampTimeout(timeoutMs || 4500);
    if (!wait) return requests.map(function () { return shapeHttpReply({ error: 'budget exhausted' }); });
    var out = [];
    for (var offset = 0; offset < requests.length; offset += 4) {
      if (!hasTime(1200)) {
        for (var rIdx = offset; rIdx < requests.length; rIdx++) {
          out.push(shapeHttpReply({ error: 'budget exhausted' }));
        }
        break;
      }
      var slice = requests.slice(offset, offset + 4);
      var shaped = slice.map(function (req) {
        return {
          url: req.url,
          method: req.method || 'GET',
          headers: buildHeaders(req.headers),
          body: req.body === undefined || req.body === null ? undefined : req.body,
          timeout: clampTimeout(req.timeout || wait) || 800
        };
      });
      if (hostHas('http.all') && myspoti.http && myspoti.http.all) {
        try {
          var batchResp = myspoti.http.all(shaped);
          for (var j = 0; j < batchResp.length; j++) {
            out.push(shapeHttpReply(batchResp[j]));
          }
          continue;
        } catch (e) {}
      }
      for (var k = 0; k < shaped.length; k++) {
        out.push(httpCall(shaped[k].method, shaped[k].url, shaped[k].body, shaped[k].headers, shaped[k].timeout));
      }
    }
    return out;
  }

// ── 01-crypto.js ──
  // ── Binary, Base64, UTF-8, PKCE, DES-ECB (JioSaavn) & AES-256-GCM (Pool v2) ─

  var B64_STD = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

  function base64ToBytes(b64) {
    var clean = String(b64 || '').replace(/[\r\n\s]/g, '').replace(/-/g, '+').replace(/_/g, '/');
    while (clean.length % 4 !== 0) clean += '=';
    var out = [];
    for (var i = 0; i < clean.length; i += 4) {
      var c0 = B64_STD.indexOf(clean.charAt(i));
      var c1 = B64_STD.indexOf(clean.charAt(i + 1));
      var c2 = clean.charAt(i + 2) === '=' ? -1 : B64_STD.indexOf(clean.charAt(i + 2));
      var c3 = clean.charAt(i + 3) === '=' ? -1 : B64_STD.indexOf(clean.charAt(i + 3));
      if (c0 < 0 || c1 < 0) break;
      var n = (c0 << 18) | (c1 << 12) | ((c2 < 0 ? 0 : c2) << 6) | (c3 < 0 ? 0 : c3);
      out.push((n >> 16) & 255);
      if (c2 >= 0) out.push((n >> 8) & 255);
      if (c3 >= 0) out.push(n & 255);
    }
    return out;
  }

  function bytesToBase64(bytes) {
    var out = '';
    for (var i = 0; i < bytes.length; i += 3) {
      var b0 = bytes[i] & 255;
      var has1 = i + 1 < bytes.length;
      var has2 = i + 2 < bytes.length;
      var b1 = has1 ? (bytes[i + 1] & 255) : 0;
      var b2 = has2 ? (bytes[i + 2] & 255) : 0;
      var n = (b0 << 16) | (b1 << 8) | b2;
      out += B64_STD.charAt((n >> 18) & 63);
      out += B64_STD.charAt((n >> 12) & 63);
      out += has1 ? B64_STD.charAt((n >> 6) & 63) : '=';
      out += has2 ? B64_STD.charAt(n & 63) : '=';
    }
    return out;
  }

  function hexToBytes(hex) {
    var s = String(hex || '').replace(/[^0-9a-fA-F]/g, '');
    var out = [];
    for (var i = 0; i + 1 < s.length; i += 2) {
      out.push(parseInt(s.substring(i, i + 2), 16) & 255);
    }
    return out;
  }

  function b64urlFromHex(hex) {
    return bytesToBase64(hexToBytes(hex))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
  }

  function randomHex(byteCount) {
    var s = '';
    for (var i = 0; i < byteCount; i++) {
      var b = Math.floor(Math.random() * 256);
      s += (b < 16 ? '0' : '') + b.toString(16);
    }
    return s;
  }

  function bytesToUtf8(bytes) {
    var out = '';
    var i = 0;
    while (i < bytes.length) {
      var b0 = bytes[i++] & 255;
      if (b0 < 0x80) {
        out += String.fromCharCode(b0);
      } else if ((b0 & 0xe0) === 0xc0 && i < bytes.length) {
        var b1 = bytes[i++] & 255;
        out += String.fromCharCode(((b0 & 0x1f) << 6) | (b1 & 0x3f));
      } else if ((b0 & 0xf0) === 0xe0 && i + 1 < bytes.length) {
        var c1 = bytes[i++] & 255;
        var c2 = bytes[i++] & 255;
        out += String.fromCharCode(((b0 & 0x0f) << 12) | ((c1 & 0x3f) << 6) | (c2 & 0x3f));
      } else if ((b0 & 0xf8) === 0xf0 && i + 2 < bytes.length) {
        var d1 = bytes[i++] & 255;
        var d2 = bytes[i++] & 255;
        var d3 = bytes[i++] & 255;
        var cp = (((b0 & 0x07) << 18) | ((d1 & 0x3f) << 12) | ((d2 & 0x3f) << 6) | (d3 & 0x3f)) - 0x10000;
        out += String.fromCharCode(0xd800 + ((cp >> 10) & 0x3ff), 0xdc00 + (cp & 0x3ff));
      }
    }
    return out;
  }

  function pkcePair() {
    var verifier = b64urlFromHex(randomHex(32));
    var challenge = b64urlFromHex(myspoti.util.sha256(verifier));
    return { verifier: verifier, challenge: challenge };
  }

  // ── Pure-JS DES-ECB Decryptor for JioSaavn (`SaavnService.kt`, key "38346591")

  var DES_IP = [
    58,50,42,34,26,18,10,2, 60,52,44,36,28,20,12,4,
    62,54,46,38,30,22,14,6, 64,56,48,40,32,24,16,8,
    57,49,41,33,25,17,9,1,  59,51,43,35,27,19,11,3,
    61,53,45,37,29,21,13,5, 63,55,47,39,31,23,15,7
  ];
  var DES_FP = [
    40,8,48,16,56,24,64,32, 39,7,47,15,55,23,63,31,
    38,6,46,14,54,22,62,30, 37,5,45,13,53,21,61,29,
    36,4,44,12,52,20,60,28, 35,3,43,11,51,19,59,27,
    34,2,42,10,50,18,58,26, 33,1,41,9,49,17,57,25
  ];
  var DES_E = [
    32,1,2,3,4,5,     4,5,6,7,8,9,
    8,9,10,11,12,13,  12,13,14,15,16,17,
    16,17,18,19,20,21,20,21,22,23,24,25,
    24,25,26,27,28,29,28,29,30,31,32,1
  ];
  var DES_P = [
    16,7,20,21,29,12,28,17, 1,15,23,26,5,18,31,10,
    2,8,24,14,32,27,3,9,    19,13,30,6,22,11,4,25
  ];
  var DES_PC1 = [
    57,49,41,33,25,17,9,  1,58,50,42,34,26,18,
    10,2,59,51,43,35,27,  19,11,3,60,52,44,36,
    63,55,47,39,31,23,15, 7,62,54,46,38,30,22,
    14,6,61,53,45,37,29,  21,13,5,28,20,12,4
  ];
  var DES_PC2 = [
    14,17,11,24,1,5,   3,28,15,6,21,10,
    23,19,12,4,26,8,   16,7,27,20,13,2,
    41,52,31,37,47,55, 30,40,51,45,33,48,
    44,49,39,56,34,53, 46,42,50,36,29,32
  ];
  var DES_SHIFTS = [1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1];
  var DES_SBOX = [
    [14,4,13,1,2,15,11,8,3,10,6,12,5,9,0,7, 0,15,7,4,14,2,13,1,10,6,12,11,9,5,3,8, 4,1,14,8,13,6,2,11,15,12,9,7,3,10,5,0, 15,12,8,2,4,9,1,7,5,11,3,14,10,0,6,13],
    [15,1,8,14,6,11,3,4,9,7,2,13,12,0,5,10, 3,13,4,7,15,2,8,14,12,0,1,10,6,9,11,5, 0,14,7,11,10,4,13,1,5,8,12,6,9,3,2,15, 13,8,10,1,3,15,4,2,11,6,7,12,0,5,14,9],
    [10,0,9,14,6,3,15,5,1,13,12,7,11,4,2,8, 13,7,0,9,3,4,6,10,2,8,5,14,12,11,15,1, 13,6,4,9,8,15,3,0,11,1,2,12,5,10,14,7, 1,10,13,0,6,9,8,7,4,15,14,3,11,5,2,12],
    [7,13,14,3,0,6,9,10,1,2,8,5,11,12,4,15, 13,8,11,5,6,15,0,3,4,7,2,12,1,10,14,9, 10,6,9,0,12,11,7,13,15,1,3,14,5,2,8,4, 3,15,0,6,10,1,13,8,9,4,5,11,12,7,2,14],
    [2,12,4,1,7,10,11,6,8,5,3,15,13,0,14,9, 14,11,2,12,4,7,13,1,5,0,15,10,3,9,8,6, 4,2,1,11,10,13,7,8,15,9,12,5,6,3,0,14, 11,8,12,7,1,14,2,13,6,15,0,9,10,4,5,3],
    [12,1,10,15,9,2,6,8,0,13,3,4,14,7,5,11, 10,15,4,2,7,12,9,5,6,1,13,14,0,11,3,8, 9,14,15,5,2,8,12,3,7,0,4,10,1,13,11,6, 4,3,2,12,9,5,15,10,11,14,1,7,6,0,8,13],
    [4,11,2,14,15,0,8,13,3,12,9,7,5,10,6,1, 13,0,11,7,4,9,1,10,14,3,5,12,2,15,8,6, 1,4,11,13,12,3,7,14,10,15,6,8,0,5,9,2, 6,11,13,8,1,4,10,7,9,5,0,15,14,2,3,12],
    [13,2,8,4,6,15,11,1,10,9,3,14,5,0,12,7, 1,15,13,8,10,3,7,4,12,5,6,11,0,14,9,2, 7,11,4,1,9,12,14,2,0,6,10,13,15,3,5,8, 2,1,14,7,4,10,8,13,15,12,9,0,3,5,6,11]
  ];

  function desBytesToBits(bytes, offset, len) {
    var bits = [];
    for (var i = 0; i < len; i++) {
      var b = bytes[offset + i] & 255;
      for (var bit = 7; bit >= 0; bit--) bits.push((b >> bit) & 1);
    }
    return bits;
  }

  function desBitsToBytes(bits) {
    var out = [];
    for (var i = 0; i < bits.length; i += 8) {
      var b = 0;
      for (var j = 0; j < 8; j++) b = (b << 1) | (bits[i + j] & 1);
      out.push(b);
    }
    return out;
  }

  function desPermute(bits, table) {
    var out = new Array(table.length);
    for (var i = 0; i < table.length; i++) out[i] = bits[table[i] - 1];
    return out;
  }

  function desRotLeft28(arr, n) {
    return arr.slice(n).concat(arr.slice(0, n));
  }

  function desSubkeys(asciiKey8) {
    var keyBytes = [];
    for (var i = 0; i < 8; i++) keyBytes.push(asciiKey8.charCodeAt(i) & 255);
    var k56 = desPermute(desBytesToBits(keyBytes, 0, 8), DES_PC1);
    var c = k56.slice(0, 28);
    var d = k56.slice(28, 56);
    var subkeys = [];
    for (var r = 0; r < 16; r++) {
      c = desRotLeft28(c, DES_SHIFTS[r]);
      d = desRotLeft28(d, DES_SHIFTS[r]);
      subkeys.push(desPermute(c.concat(d), DES_PC2));
    }
    return subkeys;
  }

  var SAAVN_SUBKEYS = null;

  function desDecryptBlock(blockBits, subkeys) {
    var perm = desPermute(blockBits, DES_IP);
    var l = perm.slice(0, 32);
    var r = perm.slice(32, 64);
    for (var round = 15; round >= 0; round--) {
      var expR = desPermute(r, DES_E);
      var k = subkeys[round];
      var sOut = [];
      for (var s = 0; s < 8; s++) {
        var off = s * 6;
        var b0 = expR[off] ^ k[off];
        var b1 = expR[off + 1] ^ k[off + 1];
        var b2 = expR[off + 2] ^ k[off + 2];
        var b3 = expR[off + 3] ^ k[off + 3];
        var b4 = expR[off + 4] ^ k[off + 4];
        var b5 = expR[off + 5] ^ k[off + 5];
        var row = (b0 << 1) | b5;
        var col = (b1 << 3) | (b2 << 2) | (b3 << 1) | b4;
        var val = DES_SBOX[s][row * 16 + col];
        sOut.push((val >> 3) & 1, (val >> 2) & 1, (val >> 1) & 1, val & 1);
      }
      var f = desPermute(sOut, DES_P);
      var nextR = new Array(32);
      for (var x = 0; x < 32; x++) nextR[x] = l[x] ^ f[x];
      l = r;
      r = nextR;
    }
    return desPermute(r.concat(l), DES_FP);
  }

  function saavnDecryptUrl(encryptedBase64) {
    if (!encryptedBase64) return '';
    var cipher = base64ToBytes(encryptedBase64);
    if (!cipher.length || cipher.length % 8 !== 0) return '';
    if (!SAAVN_SUBKEYS) SAAVN_SUBKEYS = desSubkeys('38346591');
    var plainBytes = [];
    for (var off = 0; off < cipher.length; off += 8) {
      var blk = desDecryptBlock(desBytesToBits(cipher, off, 8), SAAVN_SUBKEYS);
      var dec = desBitsToBytes(blk);
      for (var j = 0; j < 8; j++) plainBytes.push(dec[j]);
    }
    var pad = plainBytes[plainBytes.length - 1];
    if (pad >= 1 && pad <= 8) {
      var validPad = true;
      for (var p = 1; p <= pad; p++) {
        if (plainBytes[plainBytes.length - p] !== pad) {
          validPad = false;
          break;
        }
      }
      if (validPad) plainBytes.length -= pad;
    }
    return bytesToUtf8(plainBytes).trim();
  }

  // ── Pure-JS AES-256-GCM Decryptor for Cloud Pool v2 ────────────────────────

  var AES_SBOX = null;
  var AES_RCON = [0x00, 0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80, 0x1b, 0x36];

  function initAesTables() {
    if (AES_SBOX) return;
    AES_SBOX = new Array(256);
    var p = 1, q = 1;
    function rotl8(x, shift) { return ((x << shift) | (x >>> (8 - shift))) & 255; }
    do {
      p = p ^ (p << 1) ^ ((p & 0x80) ? 0x11b : 0);
      p &= 255;
      q ^= q << 1;
      q ^= q << 2;
      q ^= q << 4;
      q ^= (q & 0x80) ? 0x09 : 0;
      q &= 255;
      var xformed = q ^ rotl8(q, 1) ^ rotl8(q, 2) ^ rotl8(q, 3) ^ rotl8(q, 4);
      AES_SBOX[p] = (xformed ^ 0x63) & 255;
    } while (p !== 1);
    AES_SBOX[0] = 0x63;
  }

  function aesExpandKey256(key32) {
    initAesTables();
    var w = new Array(240);
    for (var i = 0; i < 32; i++) w[i] = key32[i] & 255;
    var rconIdx = 1;
    var temp = [0, 0, 0, 0];
    for (var pos = 32; pos < 240; pos += 4) {
      temp[0] = w[pos - 4];
      temp[1] = w[pos - 3];
      temp[2] = w[pos - 2];
      temp[3] = w[pos - 1];
      if (pos % 32 === 0) {
        var t = temp[0];
        temp[0] = AES_SBOX[temp[1]] ^ AES_RCON[rconIdx++];
        temp[1] = AES_SBOX[temp[2]];
        temp[2] = AES_SBOX[temp[3]];
        temp[3] = AES_SBOX[t];
      } else if (pos % 32 === 16) {
        temp[0] = AES_SBOX[temp[0]];
        temp[1] = AES_SBOX[temp[1]];
        temp[2] = AES_SBOX[temp[2]];
        temp[3] = AES_SBOX[temp[3]];
      }
      w[pos] = w[pos - 32] ^ temp[0];
      w[pos + 1] = w[pos - 31] ^ temp[1];
      w[pos + 2] = w[pos - 30] ^ temp[2];
      w[pos + 3] = w[pos - 29] ^ temp[3];
    }
    return w;
  }

  function aesXtime(a) {
    return ((a << 1) ^ ((a & 0x80) ? 0x1b : 0)) & 255;
  }

  function aesEncryptBlock(block16, roundKeys) {
    var s = new Array(16);
    for (var i = 0; i < 16; i++) s[i] = block16[i] ^ roundKeys[i];
    for (var round = 1; round <= 14; round++) {
      var t = new Array(16);
      for (var j = 0; j < 16; j++) t[j] = AES_SBOX[s[j]];
      // ShiftRows
      s[0] = t[0];  s[1] = t[5];  s[2] = t[10]; s[3] = t[15];
      s[4] = t[4];  s[5] = t[9];  s[6] = t[14]; s[7] = t[3];
      s[8] = t[8];  s[9] = t[13]; s[10] = t[2]; s[11] = t[7];
      s[12] = t[12];s[13] = t[1]; s[14] = t[6]; s[15] = t[11];
      // MixColumns (except final round)
      if (round < 14) {
        for (var c = 0; c < 16; c += 4) {
          var a0 = s[c], a1 = s[c + 1], a2 = s[c + 2], a3 = s[c + 3];
          var all = a0 ^ a1 ^ a2 ^ a3;
          s[c]     ^= all ^ aesXtime(a0 ^ a1);
          s[c + 1] ^= all ^ aesXtime(a1 ^ a2);
          s[c + 2] ^= all ^ aesXtime(a2 ^ a3);
          s[c + 3] ^= all ^ aesXtime(a3 ^ a0);
        }
      }
      var rkOff = round * 16;
      for (var k = 0; k < 16; k++) s[k] ^= roundKeys[rkOff + k];
    }
    return s;
  }

  function gf128Mul(x, y) {
    var z = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
    var v = y.slice(0, 16);
    for (var i = 0; i < 16; i++) {
      var xb = x[i];
      for (var bit = 7; bit >= 0; bit--) {
        if ((xb >> bit) & 1) {
          for (var j = 0; j < 16; j++) z[j] ^= v[j];
        }
        var lsb = v[15] & 1;
        for (var k = 15; k > 0; k--) v[k] = ((v[k] >>> 1) | ((v[k - 1] & 1) << 7)) & 255;
        v[0] = (v[0] >>> 1) & 255;
        if (lsb) v[0] ^= 0xe1;
      }
    }
    return z;
  }

  function gcmInc32(counter) {
    var c = counter.slice(0, 16);
    for (var i = 15; i >= 12; i--) {
      c[i] = (c[i] + 1) & 255;
      if (c[i] !== 0) break;
    }
    return c;
  }

  function aes256GcmDecrypt(key32, iv12, cipherWithTag) {
    if (!iv12 || iv12.length !== 12 || !cipherWithTag || cipherWithTag.length < 16) return null;
    var ctLen = cipherWithTag.length - 16;
    var ct = cipherWithTag.slice(0, ctLen);
    var tag = cipherWithTag.slice(ctLen);
    var rk = aesExpandKey256(key32);
    var h = aesEncryptBlock([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0], rk);
    var j0 = iv12.concat([0, 0, 0, 1]);

    // GHASH(H, {}, C)
    var y = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
    for (var off = 0; off < ctLen; off += 16) {
      for (var b = 0; b < 16 && off + b < ctLen; b++) y[b] ^= ct[off + b];
      y = gf128Mul(y, h);
    }
    var bitLen = ctLen * 8;
    var lenBlk = [0,0,0,0,0,0,0,0, 0,0,0,0, (bitLen >>> 24) & 255, (bitLen >>> 16) & 255, (bitLen >>> 8) & 255, bitLen & 255];
    for (var lb = 0; lb < 16; lb++) y[lb] ^= lenBlk[lb];
    y = gf128Mul(y, h);

    var sJ0 = aesEncryptBlock(j0, rk);
    var diff = 0;
    for (var tIdx = 0; tIdx < 16; tIdx++) {
      diff |= (sJ0[tIdx] ^ y[tIdx]) ^ tag[tIdx];
    }
    if (diff !== 0) return null;

    var plain = new Array(ctLen);
    var cb = j0;
    for (var pOff = 0; pOff < ctLen; pOff += 16) {
      cb = gcmInc32(cb);
      var ks = aesEncryptBlock(cb, rk);
      for (var pIdx = 0; pIdx < 16 && pOff + pIdx < ctLen; pIdx++) {
        plain[pOff + pIdx] = ct[pOff + pIdx] ^ ks[pIdx];
      }
    }
    return plain;
  }

  /**
   * Decrypts Cloud Pool `enc:1:<iv_b64>:<ciphertext_tag_b64>` using `SHA-256(kdfPrefix + readKey)`
   * or returns raw text if unencrypted.
   */
  function poolDecryptBody(bodyText, readKey) {
    var trimmed = String(bodyText || '').trim();
    if (trimmed.indexOf('enc:1:') !== 0) return trimmed;
    if (!readKey) return null;
    var rest = trimmed.substring(6);
    var sep = rest.indexOf(':');
    if (sep <= 0) return null;
    var iv = base64ToBytes(rest.substring(0, sep));
    var ctTag = base64ToBytes(rest.substring(sep + 1));
    var key32 = hexToBytes(myspoti.util.sha256('pool-client:' + readKey));
    var plain = aes256GcmDecrypt(key32, iv, ctTag);
    return plain ? bytesToUtf8(plain) : null;
  }

// ── 02-matching.js ──
  // ── Metadata Matching Gate (ISRC, Jaro-Winkler Similarity & Duration Gate) ──

  var EDITION_TAGS = [
    'live', 'remix', 'acoustic', 'karaoke', 'instrumental',
    'sped up', 'slowed', 'nightcore', '8d', 'reverb', 'cover', 'tribute'
  ];

  function normalizeTrackInput(track) {
    var t = track || {};
    var artists = Array.isArray(t.artists) && t.artists.length
      ? t.artists.map(function (a) { return String(a || '').trim(); }).filter(Boolean)
      : (t.artist ? [String(t.artist).trim()] : []);
    var primary = artists[0] || String(t.artist || '').trim();
    return {
      uri: String(t.uri || ''),
      id: String(t.id || (t.uri ? String(t.uri).split(':').pop() : '') || ''),
      title: String(t.title || '').trim(),
      artist: primary,
      artists: artists,
      artistsJoined: artists.join(', ') || primary,
      album: String(t.album || '').trim(),
      durationMs: Math.max(0, Number(t.durationMs || 0)),
      durationSec: t.durationMs ? Math.round(Number(t.durationMs) / 1000) : 0,
      isrc: t.isrc ? String(t.isrc).trim().toUpperCase() : '',
      ahead: !!t.ahead
    };
  }

  function stripFeaturing(s) {
    return String(s || '')
      .replace(/\s*[\(\[\{]\s*(?:feat\.?|ft\.?|featuring|with)\s+[^\)\]\}]*[\)\]\}]\s*/gi, ' ')
      .replace(/\s+(?:feat\.?|ft\.?|featuring)\s+.+$/i, '')
      .trim();
  }

  function normalizeMatchText(s) {
    return stripFeaturing(s)
      .toLowerCase()
      .replace(/[\(\[\{]\s*(?:remaster(?:ed)?|deluxe|bonus|explicit|clean|album version|single version|official[^)\]\}]*)[^\)\]\}]*[\)\]\}]?/gi, ' ')
      .replace(/[^\w\u00c0-\u024f\u0400-\u04ff\u3040-\u30ff\u4e00-\u9fff\uac00-\ud7af]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function titleSegments(raw) {
    var s = String(raw || '').trim();
    if (!s) return [];
    var parts = [normalizeMatchText(s)];
    var splitters = s.split(/\s*(?:\/|\||—|–|\s-\s)\s*/);
    for (var i = 0; i < splitters.length; i++) {
      var n = normalizeMatchText(splitters[i]);
      if (n && parts.indexOf(n) < 0) parts.push(n);
    }
    var parenMatch = /\(([^)]{2,60})\)|（([^）]{2,60})）/.exec(s);
    if (parenMatch) {
      var inner = normalizeMatchText(parenMatch[1] || parenMatch[2]);
      if (inner && parts.indexOf(inner) < 0) parts.push(inner);
      var outer = normalizeMatchText(s.replace(/\([^)]*\)|（[^）]*）/g, ' '));
      if (outer && parts.indexOf(outer) < 0) parts.push(outer);
    }
    return parts.filter(Boolean);
  }

  function hasEditionTag(raw, tag) {
    var lower = ' ' + String(raw || '').toLowerCase().replace(/[^\w\s]/g, ' ') + ' ';
    return lower.indexOf(' ' + tag + ' ') >= 0;
  }

  function editionCompatible(expectedTitle, candidateTitle) {
    for (var i = 0; i < EDITION_TAGS.length; i++) {
      var tag = EDITION_TAGS[i];
      if (hasEditionTag(expectedTitle, tag) !== hasEditionTag(candidateTitle, tag)) {
        return false;
      }
    }
    return true;
  }

  function jaroWinkler(s1, s2) {
    if (s1 === s2) return 1.0;
    if (!s1 || !s2) return 0.0;
    var len1 = s1.length;
    var len2 = s2.length;
    if (len1 > 200) s1 = s1.substring(0, 200), len1 = 200;
    if (len2 > 200) s2 = s2.substring(0, 200), len2 = 200;

    var matchDist = Math.max(0, Math.floor(Math.max(len1, len2) / 2) - 1);
    var s1Matches = new Array(len1);
    var s2Matches = new Array(len2);
    var matches = 0;

    for (var i = 0; i < len1; i++) {
      var start = Math.max(0, i - matchDist);
      var end = Math.min(i + matchDist + 1, len2);
      for (var j = start; j < end; j++) {
        if (s2Matches[j]) continue;
        if (s1.charAt(i) !== s2.charAt(j)) continue;
        s1Matches[i] = true;
        s2Matches[j] = true;
        matches++;
        break;
      }
    }
    if (matches === 0) return 0.0;

    var k = 0;
    var transpositions = 0;
    for (var m = 0; m < len1; m++) {
      if (!s1Matches[m]) continue;
      while (!s2Matches[k]) k++;
      if (s1.charAt(m) !== s2.charAt(k)) transpositions++;
      k++;
    }

    var jaro = ((matches / len1) + (matches / len2) + ((matches - transpositions / 2) / matches)) / 3.0;
    var prefix = 0;
    var maxPrefix = Math.min(4, Math.min(len1, len2));
    while (prefix < maxPrefix && s1.charAt(prefix) === s2.charAt(prefix)) prefix++;
    return jaro + prefix * 0.1 * (1.0 - jaro);
  }

  function bestSegmentSimilarity(a, b) {
    var segA = titleSegments(a);
    var segB = titleSegments(b);
    var best = 0;
    for (var i = 0; i < segA.length; i++) {
      for (var j = 0; j < segB.length; j++) {
        var s = jaroWinkler(segA[i], segB[j]);
        if (s > best) best = s;
      }
    }
    return best;
  }

  function artistSimilarity(track, candArtist) {
    if (!track.artist || !candArtist) return 0.75;
    var candNorm = normalizeMatchText(candArtist);
    if (!candNorm) return 0.75;
    var best = 0;
    var list = track.artists.length ? track.artists : [track.artist];
    for (var i = 0; i < list.length; i++) {
      var target = normalizeMatchText(list[i]);
      if (!target) continue;
      if (candNorm.indexOf(target) >= 0 || target.indexOf(candNorm) >= 0) return 1.0;
      var sim = jaroWinkler(target, candNorm);
      if (sim > best) best = sim;
    }
    return best;
  }

  /**
   * Scores a candidate `{ title, artist, durationSec, isrc }` against `track`.
   * Returns `<= 0` when rejected by the metadata similarity or Myspoti OfflineDownloader duration gate.
   */
  function scoreCandidate(track, cand, forDownload) {
    if (!cand) return -1;
    var strict = settingBool('strict_match', true);
    var candDurSec = Number(cand.durationSec || (cand.durationMs ? cand.durationMs / 1000 : 0) || 0);
    var expDurSec = track.durationSec;

    // Duration gate: Myspoti OfflineDownloader enforces [-5s, +15s] on downloads; streaming enforces +/-15s
    if (expDurSec > 0 && candDurSec > 0) {
      var diff = candDurSec - expDurSec;
      if (forDownload) {
        if (diff < -4.8 || diff > 14.5) return -1;
      } else if (Math.abs(diff) > (strict ? 15 : 25)) {
        return -1;
      }
    }

    // Exact ISRC match gets highest confidence
    if (track.isrc && cand.isrc && String(cand.isrc).trim().toUpperCase() === track.isrc) {
      return 1.5;
    }

    var candTitle = String(cand.title || '').trim();
    if (!candTitle) return -1;

    if (strict && !editionCompatible(track.title, candTitle)) {
      return -1;
    }

    var tSim = bestSegmentSimilarity(track.title, candTitle);
    var aSim = artistSimilarity(track, cand.artist || '');

    var minTitle = strict ? 0.80 : 0.68;
    var minArtist = strict ? 0.70 : 0.55;
    if (tSim < minTitle || aSim < minArtist) return -1;

    var durBonus = 0;
    if (expDurSec > 0 && candDurSec > 0) {
      var absDiff = Math.abs(candDurSec - expDurSec);
      durBonus = absDiff <= 2 ? 0.12 : absDiff <= 5 ? 0.06 : 0;
    }

    return tSim * 0.62 + aSim * 0.38 + durBonus;
  }

  function pickBestCandidate(track, list, mapper, forDownload) {
    if (!Array.isArray(list) || !list.length) return null;
    var bestItem = null;
    var bestScore = 0;
    for (var i = 0; i < list.length; i++) {
      var raw = list[i];
      var mapped = mapper ? mapper(raw) : raw;
      if (!mapped) continue;
      var sc = scoreCandidate(track, mapped, forDownload);
      if (sc > bestScore) {
        bestScore = sc;
        bestItem = mapped;
        bestItem._score = sc;
        if (sc >= 1.45) break;
      }
    }
    return bestItem;
  }

  // Optional Songlink / Odesli cross-catalog resolver (`api.song.link`, requires key since 2026)
  function resolveSonglinkLinks(track) {
    var apiKey = settingStr('songlink_key', '');
    if (!apiKey || !track.id || !hasTime(2500)) return null;
    var cacheKey = 'sl:' + track.id;
    if (memCatalogCache[cacheKey]) return memCatalogCache[cacheKey];
    var url = 'https://api.song.link/v1-alpha.1/links?url=' + enc('spotify:track:' + track.id) +
      '&userCountry=' + enc(settingStr('tidal_country', 'IT') || 'IT') +
      '&key=' + enc(apiKey);
    var r = httpGet(url, null, 2800);
    if (!r.ok || !r.json || !r.json.linksByPlatform) return null;
    var links = r.json.linksByPlatform;
    var out = {};
    if (links.tidal && links.tidal.entityUniqueId) {
      var tm = /(\d+)$/.exec(links.tidal.entityUniqueId);
      if (tm) out.tidalId = tm[1];
    }
    if (links.qobuz && links.qobuz.entityUniqueId) {
      var qm = /(\d+)$/.exec(links.qobuz.entityUniqueId);
      if (qm) out.qobuzId = qm[1];
    }
    if (links.deezer && links.deezer.entityUniqueId) {
      var dm = /(\d+)$/.exec(links.deezer.entityUniqueId);
      if (dm) out.deezerId = dm[1];
    }
    if (links.youtubeMusic && links.youtubeMusic.entityUniqueId) {
      var ym = /([A-Za-z0-9_-]{11})$/.exec(links.youtubeMusic.entityUniqueId);
      if (ym) out.videoId = ym[1];
    }
    if (links.appleMusic && links.appleMusic.entityUniqueId) {
      var am = /(\d+)$/.exec(links.appleMusic.entityUniqueId);
      if (am) out.appleId = am[1];
    }
    memCatalogCache[cacheKey] = out;
    return out;
  }

// ── 03-dash-media.js ──
  // ── Media Probing, MPEG-DASH fMP4 FLAC Normalization & Hook Shapers ─────────

  function resolveRelativeUrl(baseUrl, rel) {
    var s = decodeXmlEntities(String(rel || '').trim());
    if (!s) return '';
    if (/^https?:\/\//i.test(s)) return s;
    var base = String(baseUrl || '').trim();
    if (!base) return s;
    var qIdx = base.indexOf('?');
    var cleanBase = qIdx >= 0 ? base.substring(0, qIdx) : base;
    if (s.charAt(0) === '/') {
      var mOrigin = /^(https?:\/\/[^\/]+)/i.exec(cleanBase);
      return mOrigin ? mOrigin[1] + s : s;
    }
    var slash = cleanBase.lastIndexOf('/');
    var dir = slash > 8 ? cleanBase.substring(0, slash + 1) : cleanBase + '/';
    return dir + s;
  }

  function xmlAttr(tagText, attrName) {
    var re = new RegExp('\\b' + attrName + '\\s*=\\s*"([^"]*)"', 'i');
    var m = re.exec(tagText);
    if (m) return m[1];
    var reSingle = new RegExp("\\b" + attrName + "\\s*=\\s*'([^']*)'", 'i');
    var m2 = reSingle.exec(tagText);
    return m2 ? m2[1] : '';
  }

  function escapeXmlAttr(s) {
    return String(s || '')
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  /**
   * Normalizes a Tidal / HiFi MPEG-DASH `.mpd` XML document so Myspoti's `DashLive.parse`
   * always receives a single FLAC `<Representation>` with absolute `https://` `initialization`
   * and `media` attributes on `<SegmentTemplate>` (since `<BaseURL>` alone is rejected by Myspoti).
   */
  function normalizeDashFlacMpd(rawXml, manifestOriginUrl, wantHiRes) {
    var xml = String(rawXml || '').trim();
    if (!xml || xml.indexOf('<MPD') < 0) return null;

    var docBaseMatch = /<BaseURL[^>]*>([^<]+)<\/BaseURL>/i.exec(xml);
    var docBase = docBaseMatch ? resolveRelativeUrl(manifestOriginUrl, docBaseMatch[1]) : manifestOriginUrl;

    // Collect <Representation ...>...</Representation> or self-closing <Representation .../>
    var repRegex = /<Representation\b([^>]*?)(?:\/>|>([\s\S]*?)<\/Representation>)/gi;
    var reps = [];
    var m;
    while ((m = repRegex.exec(xml)) !== null) {
      var attrs = m[1] || '';
      var inner = m[2] || '';
      var codecs = xmlAttr(attrs, 'codecs').toLowerCase();
      var mime = xmlAttr(attrs, 'mimeType').toLowerCase();
      var bw = parseInt(xmlAttr(attrs, 'bandwidth') || '0', 10) || 0;
      var sr = parseInt(xmlAttr(attrs, 'audioSamplingRate') || '0', 10) || 0;
      var isFlac = codecs.indexOf('flac') >= 0 || mime.indexOf('flac') >= 0;
      reps.push({
        full: m[0],
        attrs: attrs,
        inner: inner,
        isFlac: isFlac,
        bandwidth: bw,
        sampleRate: sr
      });
    }

    var chosen = null;
    var flacReps = reps.filter(function (r) { return r.isFlac; });
    if (flacReps.length > 0) {
      flacReps.sort(function (a, b) {
        if (!wantHiRes) {
          var aCd = a.sampleRate > 0 && a.sampleRate <= 48000 ? 1 : 0;
          var bCd = b.sampleRate > 0 && b.sampleRate <= 48000 ? 1 : 0;
          if (aCd !== bCd) return bCd - aCd;
        }
        return (b.bandwidth - a.bandwidth) || (b.sampleRate - a.sampleRate);
      });
      chosen = flacReps[0];
    } else if (reps.length === 1 && /flac/i.test(xml)) {
      chosen = reps[0];
    } else {
      return null;
    }

    // Remove unselected <Representation> blocks when an adaptive MPD had multiple codecs
    if (reps.length > 1) {
      for (var i = 0; i < reps.length; i++) {
        if (reps[i] !== chosen) {
          xml = xml.replace(reps[i].full, '');
        }
      }
    }

    var repBaseMatch = /<BaseURL[^>]*>([^<]+)<\/BaseURL>/i.exec(chosen.inner || '');
    var effectiveBase = repBaseMatch ? resolveRelativeUrl(docBase, repBaseMatch[1]) : docBase;

    // Rewrite <SegmentTemplate ...> so initialization and media are absolute https URLs
    var hasValidTemplate = false;
    xml = xml.replace(/<SegmentTemplate\b([^>]*)>/gi, function (whole, stAttrs) {
      var initVal = xmlAttr(stAttrs, 'initialization');
      var mediaVal = xmlAttr(stAttrs, 'media');
      if (!initVal || !mediaVal) return whole;
      var absInit = resolveRelativeUrl(effectiveBase, initVal);
      var absMedia = resolveRelativeUrl(effectiveBase, mediaVal);
      if (!/^https?:\/\//i.test(absInit) || !/^https?:\/\//i.test(absMedia)) return whole;
      hasValidTemplate = true;
      var updated = stAttrs
        .replace(/\binitialization\s*=\s*(?:"[^"]*"|'[^']*')/i, 'initialization="' + escapeXmlAttr(absInit) + '"')
        .replace(/\bmedia\s*=\s*(?:"[^"]*"|'[^']*')/i, 'media="' + escapeXmlAttr(absMedia) + '"');
      return '<SegmentTemplate' + updated + '>';
    });

    if (!hasValidTemplate || xml.indexOf('<SegmentTimeline') < 0) return null;

    // Strip <BaseURL> elements now that SegmentTemplate holds full URLs
    xml = xml.replace(/<BaseURL[^>]*>[\s\S]*?<\/BaseURL>\s*/gi, '');

    var sampleRate = chosen.sampleRate || parseInt((/audioSamplingRate="(\d+)"/i.exec(xml) || [])[1] || '0', 10) || 44100;
    var bitDepth = (sampleRate > 48000 || chosen.bandwidth > 1600000) ? 24 : 16;

    return {
      manifestBase64: myspoti.util.base64Encode(xml),
      sampleRate: sampleRate,
      bitDepth: bitDepth,
      urlSample: (/initialization="([^"]+)"/i.exec(xml) || [])[1] || ''
    };
  }

  /**
   * Extracts remaining lifetime (ms) from signed CDN URLs (`token=1774196362~...`, `expires=`, `exp=`).
   */
  function urlRemainingMs(rawUrl) {
    if (!rawUrl) return 0;
    var s = decodeXmlEntities(String(rawUrl));
    var candidates = [
      /[?&](?:expires|exp|e|wsTime)=(\d{10,13})/i.exec(s),
      /[?&]token=(\d{10})~/i.exec(s),
      /exp=(\d{10})/i.exec(s)
    ];
    for (var i = 0; i < candidates.length; i++) {
      if (candidates[i]) {
        var n = parseInt(candidates[i][1], 10);
        if (n > 1000000000 && n < 100000000000) n *= 1000;
        var diff = n - Date.now();
        if (diff > 5000) return diff;
      }
    }
    return 0;
  }

  /**
   * Probes the first 42 bytes of a direct stream URL (`Range: bytes=0-41`) to confirm real audio,
   * extract total byte size from `Content-Range`, and detect format (`flac`, `mp3`, `m4a`, `webm`).
   */
  function probeAudioStream(url, extraHeaders, timeoutMs) {
    if (!url || !/^https?:\/\//i.test(url)) return null;
    var h = { 'Range': 'bytes=0-41' };
    if (extraHeaders) {
      for (var k in extraHeaders) {
        if (Object.prototype.hasOwnProperty.call(extraHeaders, k)) h[k] = extraHeaders[k];
      }
    }
    var r = httpGet(url, h, timeoutMs || 4500);
    if (r.status !== 200 && r.status !== 206) return null;
    var ct = headerValue(r.headers, 'content-type').toLowerCase();
    if (ct.indexOf('text/html') >= 0 || ct.indexOf('application/json') >= 0 || ct.indexOf('text/plain') >= 0) return null;

    var totalBytes = 0;
    var cr = headerValue(r.headers, 'content-range');
    var crMatch = /\/(\d+)\s*$/.exec(cr);
    if (crMatch) {
      totalBytes = parseInt(crMatch[1], 10) || 0;
    } else if (r.status === 200) {
      totalBytes = parseInt(headerValue(r.headers, 'content-length') || '0', 10) || 0;
    }
    if (totalBytes > 0 && totalBytes < 24576) return null;

    var body = r.text || '';
    if (body.indexOf('fLaC') === 0 || ct.indexOf('flac') >= 0) {
      return { format: 'flac', totalBytes: totalBytes };
    }
    if (body.indexOf('ID3') === 0 || ct.indexOf('mpeg') >= 0 || ct.indexOf('mp3') >= 0) {
      return { format: 'mp3', totalBytes: totalBytes };
    }
    if ((body.length >= 8 && body.substring(4, 8) === 'ftyp') || ct.indexOf('mp4') >= 0 || ct.indexOf('m4a') >= 0 || ct.indexOf('aac') >= 0) {
      return { format: 'm4a', totalBytes: totalBytes };
    }
    if (ct.indexOf('webm') >= 0 || ct.indexOf('opus') >= 0 || ct.indexOf('ogg') >= 0 || body.indexOf('OggS') === 0) {
      return { format: 'webm', totalBytes: totalBytes };
    }
    if (ct.indexOf('audio/') === 0 || ct.indexOf('application/octet-stream') >= 0) {
      if (/\.flac(?:\?|$)/i.test(url)) return { format: 'flac', totalBytes: totalBytes };
      if (/\.mp3(?:\?|$)/i.test(url)) return { format: 'mp3', totalBytes: totalBytes };
      return { format: 'm4a', totalBytes: totalBytes };
    }
    return null;
  }

  var FORBIDDEN_MEDIA_HEADERS = {
    'host': 1, 'content-length': 1, 'connection': 1, 'cookie': 1, 'set-cookie': 1,
    'transfer-encoding': 1, 'proxy-authorization': 1, 'upgrade': 1, 'x-forwarded-for': 1
  };

  function sanitizeMediaHeaders(headers) {
    if (!headers) return undefined;
    var clean = {};
    var count = 0;
    for (var k in headers) {
      if (!Object.prototype.hasOwnProperty.call(headers, k)) continue;
      if (FORBIDDEN_MEDIA_HEADERS[String(k).toLowerCase()]) continue;
      if (headers[k] != null && String(headers[k]).indexOf('\n') < 0) {
        clean[k] = String(headers[k]).substring(0, 1900);
        count++;
      }
    }
    return count > 0 ? clean : undefined;
  }

  function qualityTierRank(media) {
    if (!media) return 0;
    if (media.format === 'flac' || media.format === 'dash-flac') {
      return (media.bitDepth && media.bitDepth > 16) || (media.sampleRate && media.sampleRate > 48000) ? 3 : 2;
    }
    return 1;
  }

  function describeMediaSource(media) {
    var parts = ['Lossless FLAC · ' + (media.provider || 'Source')];
    if (media.format === 'flac' || media.format === 'dash-flac') {
      parts.push('FLAC');
      if (media.bitDepth) parts.push(media.bitDepth + '-bit');
      if (media.sampleRate) {
        var khz = media.sampleRate % 1000 === 0 ? String(media.sampleRate / 1000) : (media.sampleRate / 1000).toFixed(1);
        parts.push(khz + 'kHz');
      }
    } else if (media.format === 'm4a') {
      parts.push(media.kbps ? ('AAC ' + media.kbps + 'k') : 'AAC');
    } else if (media.format === 'mp3') {
      parts.push(media.kbps ? ('MP3 ' + media.kbps + 'k') : 'MP3');
    } else if (media.format === 'webm') {
      parts.push(media.kbps ? ('Opus ' + media.kbps + 'k') : 'Opus');
    }
    return parts.join(' · ').substring(0, 80);
  }

  function toStreamSource(media, track) {
    if (!media) return null;
    var durMs = Math.round(Number(media.durationMs || (track && track.durationMs) || 0));
    var out = {
      durationMs: durMs > 0 ? durMs : undefined,
      source: describeMediaSource(media)
    };
    var cleanHeaders = sanitizeMediaHeaders(media.headers);
    if (cleanHeaders) out.headers = cleanHeaders;

    if (media.format === 'dash-flac') {
      if (!hostHas('audio.manifest') || !media.manifest) return null;
      out.manifest = media.manifest;
      out.mimeType = 'audio/flac';
    } else {
      if (!media.url) return null;
      out.url = media.url;
      out.mimeType = media.format === 'm4a'
        ? 'audio/mp4'
        : media.format === 'mp3'
          ? 'audio/mpeg'
          : media.format === 'webm'
            ? 'audio/webm'
            : 'audio/flac';
    }

    if (hostHas('audio.quality')) {
      out.codec = media.format === 'm4a'
        ? 'aac'
        : media.format === 'mp3'
          ? 'mp3'
          : media.format === 'webm'
            ? 'opus'
            : 'flac';
      if (out.codec === 'flac' && media.bitDepth >= 8 && media.bitDepth <= 32) out.bitDepth = media.bitDepth;
      if (media.sampleRate >= 8000 && media.sampleRate <= 768000) out.sampleRate = media.sampleRate;
    }

    if (hostHas('audio.expires')) {
      var probeUrl = media.url || media.urlSample || '';
      var rem = urlRemainingMs(probeUrl);
      out.expiresInMs = rem > 45000 ? Math.min(Math.floor(rem - 30000), 600000) : STREAM_CACHE_MS;
    }
    return out;
  }

  function toDownloadFile(media) {
    if (!media) return null;
    if (media.format !== 'flac' && media.format !== 'dash-flac' && media.format !== 'm4a' && media.format !== 'mp3') {
      return null;
    }
    var f = {
      format: media.format,
      provider: ('Lossless FLAC · ' + (media.provider || 'Source')).substring(0, 40),
      isrcMatched: !!media.isrcMatched
    };
    if (media.format === 'dash-flac') {
      if (!media.manifest) return null;
      f.manifest = media.manifest;
    } else {
      if (!media.url) return null;
      f.url = media.url;
    }
    var cleanHeaders = sanitizeMediaHeaders(media.headers);
    if (cleanHeaders) f.headers = cleanHeaders;
    if ((media.format === 'flac' || media.format === 'dash-flac') && media.bitDepth >= 8 && media.bitDepth <= 32) {
      f.bitDepth = media.bitDepth;
    }
    if (media.sampleRate >= 8000 && media.sampleRate <= 768000) {
      f.sampleRate = media.sampleRate;
    }
    if (media.sizeHint && media.sizeHint > 0) {
      f.sizeHint = Math.round(media.sizeHint);
    }
    return f;
  }

// ── 04-pool.js ──
  // ── Optional Cloud Pool v2 Client (Shared Accounts + Instance Discovery) ───

  var POOL_ACCOUNTS_TTL_MS = 6 * 3600 * 1000;
  var POOL_DISCOVERY_TTL_MS = 6 * 3600 * 1000;

  function poolBaseUrl() {
    if (!settingBool('pool_enabled', false)) return '';
    return stripSlash(settingStr('pool_url', ''));
  }

  function poolReadKey() {
    return settingStr('pool_read_key', '');
  }

  function poolRequiresKey(base) {
    return !base || /\.vercel\.app/i.test(base);
  }

  function getSanitizedPoolStatus() {
    var st = myspoti.storage.get('pool.status');
    var base = poolBaseUrl();
    var readKey = poolReadKey();
    if (!base || (poolRequiresKey(base) && !readKey)) {
      if (st && st.error && /401/.test(String(st.error))) {
        myspoti.storage.remove('pool.status');
        clearCooldown('pool.accounts');
        clearCooldown('pool.discovery');
      }
      return {
        ok: false,
        noKey: true,
        at: Date.now(),
        note: 'Opzionale: nessun Cloud Pool configurato (le fonti FLAC/320k integrate funzionano senza chiave).'
      };
    }
    return st || null;
  }

  function poolAuthHeaders() {
    var h = {
      'User-Agent': 'LosslessFLAC-Android',
      'X-Pool-Client': 'v2'
    };
    var key = poolReadKey();
    if (key) h['Authorization'] = 'Bearer ' + key;
    return h;
  }

  function poolField(obj, key, readKey) {
    if (!obj || typeof obj !== 'object') return '';
    var raw = obj[key];
    if (raw === undefined || raw === null) return '';
    var str = String(raw).trim();
    if (!str) return '';
    var dec = poolDecryptBody(str, readKey);
    return dec ? String(dec).trim() : '';
  }

  function poolAccountsArray(root, service) {
    if (!root || typeof root !== 'object') return [];
    var node = root[service];
    if (Array.isArray(node)) return node;
    if (node && Array.isArray(node.accounts)) return node.accounts;
    return [];
  }

  function extractUrlsFromDiscovery(json) {
    var raw = [];
    if (Array.isArray(json)) {
      raw = json;
    } else if (json && typeof json === 'object') {
      var keys = ['instances', 'streaming', 'api', 'urls', 'data', 'servers'];
      for (var i = 0; i < keys.length; i++) {
        if (Array.isArray(json[keys[i]])) raw = raw.concat(json[keys[i]]);
      }
    }
    var out = [];
    var seen = {};
    for (var j = 0; j < raw.length; j++) {
      var item = raw[j];
      var u = typeof item === 'string' ? item : (item && (item.url || item.baseUrl || item.host));
      if (!u) continue;
      u = stripSlash(String(u).trim());
      if (!/^https:\/\//i.test(u)) continue;
      var k = u.toLowerCase();
      if (!seen[k]) {
        seen[k] = true;
        out.push(u);
      }
    }
    return out;
  }

  function getPoolAccounts(force) {
    var empty = { tidal: [], qobuz: [], deezer: [], apple: [], amazon: [] };
    if (!settingBool('pool_enabled', false)) return empty;
    var base = poolBaseUrl();
    var readKey = poolReadKey();
    if (!base || (poolRequiresKey(base) && !readKey)) {
      getSanitizedPoolStatus();
      return empty;
    }

    var cached = myspoti.storage.get('pool.accounts');
    var now = Date.now();
    if (!force && cached && cached.at && (now - cached.at < POOL_ACCOUNTS_TTL_MS)) {
      return cached.data;
    }
    if (!base || !hasTime(2800)) {
      return (cached && cached.data) || empty;
    }
    if (!force && isCooledDown('pool.accounts')) {
      return (cached && cached.data) || empty;
    }

    var r = httpGet(base + '/api/accounts', poolAuthHeaders(), 3500);
    if (r.status === 404 && hasTime(2500)) {
      r = httpGet(base + '/api/sources', poolAuthHeaders(), 3500);
    }

    if (!r.ok || !r.json) {
      var reason = r.status === 401
        ? 'HTTP 401 (chiave Cloud Pool mancante o non valida)'
        : ('HTTP ' + (r.status || 'ERR'));
      myspoti.storage.set('pool.status', { ok: false, at: now, error: reason });
      markCooldown('pool.accounts', r.status === 401 ? HARD_COOLDOWN_MS : SOFT_COOLDOWN_MS, reason);
      return (cached && cached.data) || { tidal: [], qobuz: [], deezer: [], apple: [], amazon: [] };
    }

    var root = r.json;
    var parsed = { tidal: [], qobuz: [], deezer: [], apple: [], amazon: [] };

    var tArr = poolAccountsArray(root, 'tidal');
    for (var ti = 0; ti < tArr.length; ti++) {
      var to = tArr[ti];
      var tTok = poolField(to, 'token', readKey);
      if (!tTok) continue;
      parsed.tidal.push({
        id: to.id || 0,
        token: tTok,
        refreshToken: poolField(to, 'refreshToken', readKey),
        countryCode: poolField(to, 'countryCode', readKey) || 'US',
        premium: to.premium !== false
      });
    }

    var qArr = poolAccountsArray(root, 'qobuz');
    for (var qi = 0; qi < qArr.length; qi++) {
      var qo = qArr[qi];
      var qTok = poolField(qo, 'token', readKey);
      var qApp = poolField(qo, 'appId', readKey);
      var qSec = poolField(qo, 'appSecret', readKey);
      if (!qTok || !qApp || !qSec) continue;
      parsed.qobuz.push({
        id: qo.id || 0,
        token: qTok,
        appId: qApp,
        appSecret: qSec,
        premium: qo.premium !== false
      });
    }

    var dArr = poolAccountsArray(root, 'deezer');
    for (var di = 0; di < dArr.length; di++) {
      var dObj = dArr[di];
      var dArl = poolField(dObj, 'arl', readKey);
      if (!dArl) continue;
      parsed.deezer.push({
        id: dObj.id || 0,
        arl: dArl,
        premium: dObj.premium !== false
      });
    }

    var aArr = poolAccountsArray(root, 'apple-music');
    for (var ai = 0; ai < aArr.length; ai++) {
      var aObj = aArr[ai];
      var aTok = poolField(aObj, 'token', readKey);
      if (!aTok) continue;
      parsed.apple.push({
        id: aObj.id || 0,
        mediaUserToken: aTok,
        premium: aObj.premium !== false
      });
    }

    var amzArr = poolAccountsArray(root, 'amazon-music');
    for (var mi = 0; mi < amzArr.length; mi++) {
      var mObj = amzArr[mi];
      var mBase = mObj && mObj.baseUrl ? stripSlash(String(mObj.baseUrl).trim()) : '';
      if (!mBase) continue;
      parsed.amazon.push({
        id: mObj.id || 0,
        baseUrl: mBase,
        bypassToken: poolField(mObj, 'bypassToken', readKey),
        turnstileJwt: poolField(mObj, 'turnstileJwt', readKey),
        expiresAt: mObj.turnstileJwtExpiresAt ? (Date.parse(mObj.turnstileJwtExpiresAt) || 0) : 0
      });
    }

    myspoti.storage.set('pool.accounts', { at: now, data: parsed });
    myspoti.storage.set('pool.status', {
      ok: true,
      at: now,
      counts: {
        tidal: parsed.tidal.length,
        qobuz: parsed.qobuz.length,
        deezer: parsed.deezer.length,
        apple: parsed.apple.length,
        amazon: parsed.amazon.length
      }
    });
    clearCooldown('pool.accounts');
    return parsed;
  }

  function getPoolDiscovery(force) {
    var out = { tidal: [], qobuz: [], deezer: [] };
    if (!settingBool('pool_enabled', false)) return out;
    var base = poolBaseUrl();
    var readKey = poolReadKey();
    if (!base || (poolRequiresKey(base) && !readKey)) {
      return out;
    }

    var cached = myspoti.storage.get('pool.discovery');
    var now = Date.now();
    if (!force && cached && cached.at && (now - cached.at < POOL_DISCOVERY_TTL_MS)) {
      return cached.data;
    }
    if (!hasTime(2800) || (!force && isCooledDown('pool.discovery'))) {
      return (cached && cached.data) || out;
    }

    var headers = poolAuthHeaders();
    var reqs = [
      { url: base + '/api/discovery/tidal', headers: headers, timeout: 3000 },
      { url: base + '/api/discovery/qobuz', headers: headers, timeout: 3000 },
      { url: base + '/api/instances/deezer', headers: headers, timeout: 3000 }
    ];
    var resps = httpBatch(reqs, 3200);
    if (resps[0] && resps[0].ok && resps[0].json) out.tidal = extractUrlsFromDiscovery(resps[0].json);
    if (resps[1] && resps[1].ok && resps[1].json) out.qobuz = extractUrlsFromDiscovery(resps[1].json);
    if (resps[2] && resps[2].ok && resps[2].json) out.deezer = extractUrlsFromDiscovery(resps[2].json);

    if (!out.tidal.length && !out.qobuz.length && !out.deezer.length) {
      markCooldown('pool.discovery', SOFT_COOLDOWN_MS, 'no discovery instances');
      return (cached && cached.data) || out;
    }

    myspoti.storage.set('pool.discovery', { at: now, data: out });
    clearCooldown('pool.discovery');
    return out;
  }

  function orderHealthyUrls(urls, prefix) {
    var fresh = [];
    var cooled = [];
    var seen = {};
    for (var i = 0; i < urls.length; i++) {
      var u = stripSlash(urls[i]);
      if (!u) continue;
      var k = u.toLowerCase();
      if (seen[k]) continue;
      seen[k] = true;
      if (isCooledDown(prefix + ':' + k)) cooled.push(u);
      else fresh.push(u);
    }
    return fresh.concat(cooled.slice(0, 1));
  }

// ── 05-audio-tidal.js ──
  // ── Source 1: TIDAL (`TidalAccountManager.kt` + `TidalAudioProvider.kt`) ────

  var TIDAL_PUBLIC_TOKEN = '49YxDN9a2aFV6RTG';
  var TIDAL_PKCE_CLIENT_ID = '6BDSRdpK9hqEBTgU';
  var TIDAL_PKCE_CLIENT_SECRET = 'xeuPmY7nbpZ9IIbLAcQ93shka1VNheUAqN6IcszjTG8=';
  var TIDAL_DEVICE_CLIENT_ID = 'fX2JxdmntZWK0ixT';
  var TIDAL_DEVICE_CLIENT_SECRET = '1Nn9AfDAjxrgJFJbKNWLeAyKGVGmINuXPPLHVXAvxAg=';
  var TIDAL_PKCE_REDIRECT_URI = 'https://tidal.com/android/login/auth';
  var TIDAL_AUTH_ENDPOINT = 'https://login.tidal.com/authorize';
  var TIDAL_TOKEN_ENDPOINT = 'https://auth.tidal.com/v1/oauth2/token';
  var TIDAL_API_BASE = 'https://api.tidal.com/v1';

  function startTidalPkceLogin() {
    var pair = pkcePair();
    var uniqueKey = randomHex(8);
    var authUrl = TIDAL_AUTH_ENDPOINT +
      '?response_type=code' +
      '&redirect_uri=' + enc(TIDAL_PKCE_REDIRECT_URI) +
      '&client_id=' + enc(TIDAL_PKCE_CLIENT_ID) +
      '&lang=EN&appMode=android' +
      '&client_unique_key=' + enc(uniqueKey) +
      '&code_challenge=' + enc(pair.challenge) +
      '&code_challenge_method=S256' +
      '&restrict_signup=true';
    var authId = myspoti.auth.open({
      url: authUrl,
      callback: TIDAL_PKCE_REDIRECT_URI,
      hidden: false
    });
    myspoti.storage.set('tidal.pkce', {
      authId: authId,
      verifier: pair.verifier,
      uniqueKey: uniqueKey,
      at: Date.now()
    });
    appendDiag('tidal', 'Avviato login OAuth2 PKCE Tidal');
    return { ok: true, authId: authId, url: authUrl };
  }

  function exchangeTidalCallbackUrl(callbackUrl) {
    var pkce = myspoti.storage.get('tidal.pkce');
    if (!pkce || !pkce.verifier) return { ok: false, message: 'Sessione PKCE non trovata' };
    var codeMatch = /[?&]code=([^&#]+)/.exec(String(callbackUrl || ''));
    if (!codeMatch) return { ok: false, message: 'Nessun codice OAuth nell\'URL di ritorno' };
    var code = '';
    try { code = decodeURIComponent(codeMatch[1]); } catch (e) { code = codeMatch[1]; }

    var form = myspoti.query({
      code: code,
      client_id: TIDAL_PKCE_CLIENT_ID,
      client_secret: TIDAL_PKCE_CLIENT_SECRET,
      grant_type: 'authorization_code',
      redirect_uri: TIDAL_PKCE_REDIRECT_URI,
      scope: 'r_usr+w_usr+w_sub',
      code_verifier: pkce.verifier,
      client_unique_key: pkce.uniqueKey
    });
    var r = httpPost(TIDAL_TOKEN_ENDPOINT, form, {
      'Content-Type': 'application/x-www-form-urlencoded'
    }, 8000);
    if (!r.ok || !r.json || !r.json.access_token) {
      return { ok: false, message: 'Scambio token Tidal fallito (HTTP ' + r.status + ')' };
    }
    var user = r.json.user || {};
    var session = {
      accessToken: r.json.access_token,
      refreshToken: r.json.refresh_token || '',
      expiresAt: Date.now() + (Number(r.json.expires_in || 3600) * 1000),
      userId: user.userId || 0,
      username: user.username || user.email || '',
      countryCode: user.countryCode || settingStr('tidal_country', 'IT') || 'IT',
      flow: 'pkce'
    };
    myspoti.storage.set('tidal.session', session);
    myspoti.storage.remove('tidal.pkce');
    appendDiag('tidal', 'Account Tidal collegato (' + (session.username || session.countryCode) + ')');
    return { ok: true, message: 'Account Tidal collegato con successo', session: session };
  }

  function refreshTidalToken(refreshToken, flow) {
    if (!refreshToken || !hasTime(2500)) return null;
    var isPkce = flow !== 'oauth';
    var form = myspoti.query({
      client_id: isPkce ? TIDAL_PKCE_CLIENT_ID : TIDAL_DEVICE_CLIENT_ID,
      client_secret: isPkce ? TIDAL_PKCE_CLIENT_SECRET : TIDAL_DEVICE_CLIENT_SECRET,
      refresh_token: refreshToken,
      grant_type: 'refresh_token',
      scope: 'r_usr+w_usr+w_sub'
    });
    var r = httpPost(TIDAL_TOKEN_ENDPOINT, form, {
      'Content-Type': 'application/x-www-form-urlencoded'
    }, 4500);
    if (!r.ok || !r.json || !r.json.access_token) return null;
    var user = r.json.user || {};
    return {
      accessToken: r.json.access_token,
      refreshToken: r.json.refresh_token || refreshToken,
      expiresAt: Date.now() + (Number(r.json.expires_in || 3600) * 1000),
      countryCode: user.countryCode || '',
      username: user.username || ''
    };
  }

  function getActiveUserTidalSession() {
    var manual = settingStr('tidal_token', '').replace(/^Bearer\s+/i, '').trim();
    if (manual) {
      return { accessToken: manual, countryCode: settingStr('tidal_country', 'IT') || 'IT', source: 'manual' };
    }
    var sess = myspoti.storage.get('tidal.session');
    if (!sess || !sess.accessToken) return null;
    if (sess.expiresAt && sess.expiresAt - Date.now() < 120000 && sess.refreshToken) {
      var renewed = refreshTidalToken(sess.refreshToken, sess.flow || 'pkce');
      if (renewed) {
        sess.accessToken = renewed.accessToken;
        sess.refreshToken = renewed.refreshToken;
        sess.expiresAt = renewed.expiresAt;
        if (renewed.countryCode) sess.countryCode = renewed.countryCode;
        myspoti.storage.set('tidal.session', sess);
      }
    }
    return sess;
  }

  function logoutTidalSession() {
    myspoti.storage.remove('tidal.session');
    myspoti.storage.remove('tidal.pkce');
    appendDiag('tidal', 'Sessione Tidal disconnessa');
  }

  function resolveTidalCatalogTrack(track, forDownload) {
    var cacheKey = 'tidal:' + (track.isrc || (track.artist + ' - ' + track.title));
    if (memCatalogCache[cacheKey]) return memCatalogCache[cacheKey];

    var country = settingStr('tidal_country', 'IT').toUpperCase() || 'IT';
    var userSess = getActiveUserTidalSession();
    if (userSess && userSess.countryCode) country = userSess.countryCode;

    // 1. Optional Songlink shortcut
    var sl = resolveSonglinkLinks(track);
    if (sl && sl.tidalId) {
      var slHit = { id: String(sl.tidalId), isrcMatched: !!track.isrc };
      memCatalogCache[cacheKey] = slHit;
      return slHit;
    }

    // 2. Direct Tidal public catalog search (supports artist+title & returns exact item.isrc)
    var q = (track.artist ? (track.artist + ' ' + track.title) : track.title).trim();
    var headers = { 'x-tidal-token': TIDAL_PUBLIC_TOKEN };
    if (userSess && userSess.accessToken) headers['Authorization'] = 'Bearer ' + userSess.accessToken;

    var searchUrl = TIDAL_API_BASE + '/search/tracks?query=' + enc(q) + '&limit=10&countryCode=' + enc(country);
    var r = httpGet(searchUrl, headers, 3200);
    if (!r.ok && headers['Authorization']) {
      r = httpGet(searchUrl, { 'x-tidal-token': TIDAL_PUBLIC_TOKEN }, 3000);
    }

    var items = r.ok && r.json && Array.isArray(r.json.items) ? r.json.items : [];
    var picked = pickBestCandidate(track, items, function (it) {
      if (!it || !it.id || it.allowStreaming === false) return null;
      var artName = '';
      if (Array.isArray(it.artists) && it.artists.length) {
        artName = it.artists.map(function (a) { return a && a.name; }).filter(Boolean).join(', ');
      } else if (it.artist && it.artist.name) {
        artName = it.artist.name;
      }
      var titleFull = String(it.title || '') + (it.version ? (' (' + it.version + ')') : '');
      return {
        id: String(it.id),
        title: titleFull,
        artist: artName,
        durationSec: Number(it.duration || 0),
        isrc: it.isrc ? String(it.isrc).toUpperCase() : '',
        audioQuality: it.audioQuality || '',
        tags: (it.mediaMetadata && Array.isArray(it.mediaMetadata.tags)) ? it.mediaMetadata.tags : []
      };
    }, forDownload);

    if (picked) {
      if (!track.isrc && picked.isrc) track.isrc = picked.isrc;
      var res = {
        id: picked.id,
        isrc: picked.isrc || track.isrc || '',
        isrcMatched: !!(track.isrc && picked.isrc === track.isrc),
        tags: picked.tags
      };
      memCatalogCache[cacheKey] = res;
      return res;
    }
    return null;
  }

  function cleanTrackSearchQuery(artist, title) {
    var cleanT = String(title || '')
      .replace(/\s*[\(\[\{](?:feat|ft|featuring|with)\b[^\)\]\}]*[\)\]\}]/gi, '')
      .replace(/\s*-\s*(?:\d{4}\s*)?remaster(?:ed)?(?:\s*\d{4})?\b.*$/i, '')
      .replace(/['’`´]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    var cleanA = String(artist || '').replace(/['’`´]/g, ' ').replace(/\s+/g, ' ').trim();
    return ((cleanA ? (cleanA + ' ') : '') + (cleanT || title || '')).trim();
  }

  function mapMonochromeItem(it) {
    if (!it || it.playable === false) return null;
    var tid = String(it.trackId || it.recordingId || it.id || '').trim();
    if (!tid) return null;
    var artistStr = '';
    if (Array.isArray(it.artistNames) && it.artistNames.length) {
      artistStr = it.artistNames.filter(Boolean).join(', ');
    } else if (Array.isArray(it.artists) && it.artists.length) {
      artistStr = it.artists.map(function (a) { return typeof a === 'string' ? a : (a && a.name); }).filter(Boolean).join(', ');
    } else if (it.artist) {
      artistStr = typeof it.artist === 'string' ? it.artist : String(it.artist.name || '');
    }
    var rawDur = Number(it.duration || 0);
    var durSec = rawDur > 1000 ? Math.round(rawDur / 1000) : Math.round(rawDur);
    var durMs = rawDur > 1000 ? Math.round(rawDur) : Math.round(rawDur * 1000);
    return {
      id: tid,
      title: String(it.title || ''),
      artist: artistStr,
      durationSec: durSec,
      durationMs: durMs,
      isrc: it.isrc ? String(it.isrc).toUpperCase() : ''
    };
  }

  /**
   * Zero-config Lossless / Hi-Res FLAC resolver via Monochrome / HiFi Track Streamer v2.10
   * (`https://tracks.monochrome.st`). Uses a fast 2.2s search timeout and 5-minute cooldown
   * when the upstream host is unreachable so playback immediately falls over to healthy sources.
   */
  function resolveMonochromeTracksSource(track, wantTier, forDownload) {
    if (!settingBool('monochrome_enabled', true) || !hasTime(2400)) return null;
    var base = stripSlash(settingStr('monochrome_url', 'https://tracks.monochrome.st'));
    if (!base || !/^https:\/\//i.test(base)) return null;
    var coolKey = 'mono_v210:' + base.toLowerCase();
    if (isCooledDown(coolKey)) return null;

    var rawQuery = ((track.artist ? (track.artist + ' ') : '') + track.title).trim();
    if (!rawQuery) return null;

    var isrcCacheKey = 'isrc:' + (track.uri || rawQuery.toLowerCase());
    if (!track.isrc && memCatalogCache[isrcCacheKey]) {
      track.isrc = memCatalogCache[isrcCacheKey];
    }

    var monoUrl = base + '/search/tracks?q=' + enc(rawQuery) + '&limit=10';
    var monoResp = httpGet(monoUrl, { 'Accept': 'application/json' }, 2200);

    if (!monoResp || !monoResp.ok || !monoResp.json) {
      if (!monoResp || monoResp.status === 0 || monoResp.status >= 500 || monoResp.status === 429) {
        markCooldown(coolKey, 300000, 'HTTP ' + (monoResp ? monoResp.status : 0));
      }
      return null;
    }

    var rawList = Array.isArray(monoResp.json.tracks)
      ? monoResp.json.tracks
      : (Array.isArray(monoResp.json.items) ? monoResp.json.items : []);
    var picked = pickBestCandidate(track, rawList, mapMonochromeItem, forDownload);

    if (!picked && hasTime(2600)) {
      var altQuery = cleanTrackSearchQuery(track.artist, track.title);
      if (altQuery && altQuery.toLowerCase() !== rawQuery.toLowerCase()) {
        var altResp = httpGet(base + '/search/tracks?q=' + enc(altQuery) + '&limit=10', { 'Accept': 'application/json' }, 2200);
        if (altResp.ok && altResp.json) {
          var altList = Array.isArray(altResp.json.tracks) ? altResp.json.tracks : [];
          picked = pickBestCandidate(track, altList, mapMonochromeItem, forDownload);
        }
      }
    }

    if (!picked) return null;
    if (!track.isrc && picked.isrc) {
      track.isrc = picked.isrc;
      memCatalogCache[isrcCacheKey] = picked.isrc;
    }

    var streamUrl = base + '/track/' + enc(picked.id);
    clearCooldown(coolKey);

    // For live streaming (`!forDownload`), avoid pre-hitting `/track/<id>` from JS so ExoPlayer's
    // immediate request does not trigger per-IP HTTP 429 rate-limiting on Monochrome.
    if (!forDownload) {
      return {
        format: 'flac',
        url: streamUrl,
        bitDepth: 16,
        sampleRate: 44100,
        durationMs: picked.durationMs || track.durationMs || undefined,
        provider: 'Tidal / Monochrome',
        isrcMatched: !!(track.isrc && picked.isrc && picked.isrc === track.isrc)
      };
    }

    if (!hasTime(2400)) return null;
    var probeWait = Math.min(6000, Math.max(2200, timeLeft() - 300));
    var probed = probeAudioStream(streamUrl, null, probeWait);
    if (!probed) return null;

    var durSec = picked.durationSec || Math.round((track.durationMs || 0) / 1000) || 200;
    var kbps = (probed.totalBytes && durSec > 0) ? Math.round((probed.totalBytes * 8) / (durSec * 1000)) : 0;
    var bitDepth = 16;
    var sampleRate = 44100;
    if (probed.format === 'flac') {
      if (kbps >= 4000) { bitDepth = 24; sampleRate = 192000; }
      else if (kbps >= 2400) { bitDepth = 24; sampleRate = 96000; }
      else if (kbps >= 1420) { bitDepth = 24; sampleRate = 48000; }
    }

    return {
      format: probed.format,
      url: streamUrl,
      bitDepth: probed.format === 'flac' ? bitDepth : undefined,
      sampleRate: sampleRate,
      kbps: kbps || undefined,
      sizeHint: probed.totalBytes || undefined,
      durationMs: picked.durationMs || track.durationMs || undefined,
      provider: 'Tidal / Monochrome',
      isrcMatched: !!(track.isrc && picked.isrc && picked.isrc === track.isrc)
    };
  }

  function parseTidalPlaybackPayload(data, providerLabel, wantHiRes, isrcMatched) {
    if (!data || typeof data !== 'object') return null;
    if (data.assetPresentation === 'PREVIEW' || data.trackPresentation === 'PREVIEW') return null;

    var mime = String(data.manifestMimeType || '').toLowerCase();
    var b64 = data.manifest || '';
    var bd = Number(data.bitDepth || 0);
    var sr = Number(data.sampleRate || 0);
    var aq = String(data.audioQuality || '').toUpperCase();

    if (b64 && mime.indexOf('tidal.bts') >= 0) {
      var decodedStr = '';
      try { decodedStr = myspoti.util.base64Decode(b64); } catch (e) { decodedStr = ''; }
      if (!decodedStr) return null;
      var bts = null;
      try { bts = JSON.parse(decodedStr); } catch (e) { bts = null; }
      if (!bts || (bts.encryptionType && bts.encryptionType !== 'NONE')) return null;
      var directUrl = Array.isArray(bts.urls) && bts.urls[0] ? String(bts.urls[0]) : '';
      if (!directUrl) return null;
      var codecs = String(bts.codecs || bts.mimeType || '').toLowerCase();
      var isFlac = codecs.indexOf('flac') >= 0 || aq === 'LOSSLESS' || aq === 'HI_RES_LOSSLESS';
      return {
        format: isFlac ? 'flac' : 'm4a',
        url: directUrl,
        bitDepth: isFlac ? (bd || 16) : undefined,
        sampleRate: sr || 44100,
        kbps: isFlac ? undefined : (aq === 'HIGH' ? 320 : 96),
        provider: providerLabel,
        isrcMatched: !!isrcMatched
      };
    }

    if (b64 && (mime.indexOf('dash+xml') >= 0 || b64.length > 40)) {
      var rawXml = '';
      try { rawXml = myspoti.util.base64Decode(b64); } catch (e) { rawXml = ''; }
      if (rawXml && rawXml.indexOf('<MPD') >= 0) {
        var norm = normalizeDashFlacMpd(rawXml, '', wantHiRes);
        if (norm) {
          return {
            format: 'dash-flac',
            manifest: norm.manifestBase64,
            urlSample: norm.urlSample,
            bitDepth: bd || norm.bitDepth || 24,
            sampleRate: sr || norm.sampleRate || 44100,
            provider: providerLabel,
            isrcMatched: !!isrcMatched
          };
        }
      }
    }
    return null;
  }

  function tidalQualityOrder(wantTier) {
    if (wantTier === 'HIGH' || wantTier === 'small') return ['HIGH', 'LOSSLESS'];
    if (wantTier === 'LOSSLESS' || wantTier === 'cd') return ['LOSSLESS', 'HIGH'];
    return ['HI_RES_LOSSLESS', 'LOSSLESS', 'HIGH'];
  }

  function resolveTidalWithBearer(tidalId, token, label, wantTier, isrcMatched) {
    if (!token || !hasTime(2000)) return null;
    var qualities = tidalQualityOrder(wantTier);
    var wantHiRes = qualities[0] === 'HI_RES_LOSSLESS';
    for (var i = 0; i < qualities.length; i++) {
      if (!hasTime(1600)) break;
      var q = qualities[i];
      var url = TIDAL_API_BASE + '/tracks/' + enc(tidalId) +
        '/playbackinfopostpaywall?audioquality=' + enc(q) +
        '&playbackmode=STREAM&assetpresentation=FULL';
      var r = httpGet(url, { 'Authorization': 'Bearer ' + token }, 3500);
      if (r.status === 401 || r.status === 403) return { authFailed: true, status: r.status };
      if (!r.ok || !r.json) continue;
      var parsed = parseTidalPlaybackPayload(r.json, label, wantHiRes, isrcMatched);
      if (parsed) return parsed;
    }
    return null;
  }

  function resolveTidalFromInstances(tidalId, track, wantTier, isrcMatched) {
    var userUrls = settingUrlList('tidal_instances');
    var discUrls = (!aheadMode && settingBool('pool_enabled', true)) ? (getPoolDiscovery(false).tidal || []) : [];
    var instances = orderHealthyUrls(userUrls.concat(discUrls), 'tidal_inst').slice(0, aheadMode ? 3 : 6);
    if (!instances.length || !hasTime(2200)) return null;

    var wantLossy = wantTier === 'HIGH' || wantTier === 'small';
    var wantHiRes = !wantLossy && wantTier !== 'LOSSLESS' && wantTier !== 'cd';
    var qualityParam = wantLossy ? 'HIGH' : (wantHiRes ? 'HI_RES_LOSSLESS' : 'LOSSLESS');

    // Race up to 4 instances at once on `/track/` (returns inline manifest JSON or MPD)
    var trackReqs = instances.slice(0, 4).map(function (base) {
      return {
        url: base + '/track/?id=' + enc(tidalId) + '&quality=' + enc(qualityParam),
        timeout: 3400
      };
    });
    var trackResps = httpBatch(trackReqs, 3600);
    for (var i = 0; i < trackResps.length; i++) {
      var base = instances[i];
      var r = trackResps[i];
      if (!r.ok || !r.json) {
        if (r.status === 401 || r.status === 403) markCooldown('tidal_inst:' + base.toLowerCase(), HARD_COOLDOWN_MS, 'HTTP ' + r.status);
        else if (r.status >= 429 || r.status === 0) markCooldown('tidal_inst:' + base.toLowerCase(), SOFT_COOLDOWN_MS, 'HTTP ' + r.status);
        continue;
      }
      var payload = (r.json.data && typeof r.json.data === 'object' && !Array.isArray(r.json.data)) ? r.json.data : r.json;
      var media = parseTidalPlaybackPayload(payload, 'Tidal HiFi', wantHiRes, isrcMatched);
      if (media) {
        clearCooldown('tidal_inst:' + base.toLowerCase());
        return media;
      }
    }

    // Try HiFi v2.7+ `/trackManifests/` for Hi-Res/CD MPEG-DASH `.mpd` URI
    if (!wantLossy && hasTime(2600)) {
      var fmtQuery = wantHiRes ? 'formats=FLAC_HIRES&formats=FLAC' : 'formats=FLAC';
      var mfReqs = instances.slice(0, 3).map(function (base) {
        return {
          url: base + '/trackManifests/?id=' + enc(tidalId) + '&' + fmtQuery +
            '&adaptive=false&manifestType=MPEG_DASH&uriScheme=HTTPS&usage=PLAYBACK',
          timeout: 3200
        };
      });
      var mfResps = httpBatch(mfReqs, 3400);
      for (var mIdx = 0; mIdx < mfResps.length; mIdx++) {
        var mf = mfResps[mIdx];
        if (!mf.ok || !mf.json || !hasTime(1600)) continue;
        var attrs = mf.json.data && mf.json.data.data && mf.json.data.data.attributes;
        if (!attrs || attrs.trackPresentation === 'PREVIEW' || !attrs.uri) continue;
        var mpdResp = httpGet(String(attrs.uri), { 'Accept': 'application/dash+xml, text/xml, */*' }, 2800);
        if (!mpdResp.ok || !mpdResp.text) continue;
        var normMpd = normalizeDashFlacMpd(mpdResp.text, String(attrs.uri), wantHiRes);
        if (normMpd) {
          clearCooldown('tidal_inst:' + instances[mIdx].toLowerCase());
          return {
            format: 'dash-flac',
            manifest: normMpd.manifestBase64,
            urlSample: normMpd.urlSample,
            bitDepth: normMpd.bitDepth,
            sampleRate: normMpd.sampleRate,
            provider: 'Tidal HiFi DASH',
            isrcMatched: !!isrcMatched
          };
        }
      }
    }
    return null;
  }

  function resolveTidalSource(track, wantTier, forDownload) {
    if (!settingBool('tidal_enabled', true) || !hasTime(2000)) return null;
    var userSess = getActiveUserTidalSession();
    var poolAccs = getPoolAccounts(false).tidal || [];
    var userInst = settingUrlList('tidal_instances').filter(function (u) {
      return !/tracks\.monochrome\.st/i.test(u);
    });
    var discInst = (!aheadMode && settingBool('pool_enabled', true)) ? (getPoolDiscovery(false).tidal || []) : [];
    var hasLegacyTidal = !!(userSess || poolAccs.length || userInst.length || discInst.length);

    if (hasLegacyTidal) {
      var cat = resolveTidalCatalogTrack(track, forDownload);
      if (cat && cat.id) {
        // 1. User Tidal Account (PKCE or manual Bearer)
        if (userSess && userSess.accessToken) {
          var resUser = resolveTidalWithBearer(cat.id, userSess.accessToken, 'Tidal Account', wantTier, cat.isrcMatched);
          if (resUser && resUser.authFailed && userSess.refreshToken) {
            var refreshed = refreshTidalToken(userSess.refreshToken, userSess.flow || 'pkce');
            if (refreshed) {
              userSess.accessToken = refreshed.accessToken;
              userSess.refreshToken = refreshed.refreshToken;
              userSess.expiresAt = refreshed.expiresAt;
              myspoti.storage.set('tidal.session', userSess);
              resUser = resolveTidalWithBearer(cat.id, userSess.accessToken, 'Tidal Account', wantTier, cat.isrcMatched);
            }
          }
          if (resUser && !resUser.authFailed) return resUser;
        }

        // 2. Cloud Pool Shared Tidal Accounts
        for (var p = 0; p < poolAccs.length && p < 3; p++) {
          if (!hasTime(1800)) break;
          var acc = poolAccs[p];
          if (isCooledDown('pool.tidal:' + acc.id)) continue;
          var resPool = resolveTidalWithBearer(cat.id, acc.token, 'Tidal Pool', wantTier, cat.isrcMatched);
          if (resPool && resPool.authFailed) {
            markCooldown('pool.tidal:' + acc.id, HARD_COOLDOWN_MS, 'HTTP ' + resPool.status);
            continue;
          }
          if (resPool) return resPool;
        }

        // 3. Custom Tidal HiFi v2.0 / v2.7 Instances (`/track/`, `/trackManifests/`)
        if (userInst.length || discInst.length) {
          var instRes = resolveTidalFromInstances(cat.id, track, wantTier, cat.isrcMatched);
          if (instRes) return instRes;
        }
      }
    }

    // 4. Built-in Zero-Config Monochrome / HiFi Track Streamer v2.10 (`tracks.monochrome.st`)
    return resolveMonochromeTracksSource(track, wantTier, forDownload);
  }

// ── 06-audio-qobuz.js ──
  // ── Source 2: QOBUZ (`QobuzAudioProvider.kt`) & Source 3: QOBUZ BACKUP ──────

  var QOBUZ_API_BASE = 'https://www.qobuz.com/api.json/0.2';
  var QOBUZ_DEFAULT_APP_ID = '712109809';
  var QOBUZ_ALT_APP_ID = '798273057';
  var QOBUZ_DEFAULT_SECRET = '589be88e4538daea11f509d29e4a23b1';

  function qobuzFormatOrder(wantTier) {
    if (wantTier === 'HIGH' || wantTier === 'small') return [5, 6];
    if (wantTier === 'LOSSLESS' || wantTier === 'cd') return [6, 5];
    return [27, 7, 6, 5];
  }

  function resolveQobuzDirectWithCreds(track, cred, label, wantTier, forDownload) {
    if (!cred || !cred.appId || !cred.appSecret || !cred.token || !hasTime(2200)) return null;
    var q = track.isrc || ((track.artist ? (track.artist + ' ') : '') + track.title).trim();
    var headers = {
      'X-App-Id': cred.appId,
      'X-User-Auth-Token': cred.token
    };
    var searchResp = httpGet(QOBUZ_API_BASE + '/track/search?query=' + enc(q) + '&limit=8', headers, 3200);
    var items = searchResp.ok && searchResp.json && searchResp.json.tracks && Array.isArray(searchResp.json.tracks.items)
      ? searchResp.json.tracks.items : [];
    if (!items.length && track.isrc && hasTime(2000)) {
      var fallbackQ = ((track.artist ? (track.artist + ' ') : '') + track.title).trim();
      var sr2 = httpGet(QOBUZ_API_BASE + '/track/search?query=' + enc(fallbackQ) + '&limit=8', headers, 3000);
      items = sr2.ok && sr2.json && sr2.json.tracks && Array.isArray(sr2.json.tracks.items) ? sr2.json.tracks.items : [];
    }

    var picked = pickBestCandidate(track, items, function (it) {
      if (!it || !it.id || it.streamable === false) return null;
      var performer = (it.performer && it.performer.name) || (it.album && it.album.artist && it.album.artist.name) || '';
      var titleFull = String(it.title || '') + (it.version ? (' (' + it.version + ')') : '');
      return {
        id: String(it.id),
        title: titleFull,
        artist: performer,
        durationSec: Number(it.duration || 0),
        isrc: it.isrc ? String(it.isrc).toUpperCase() : ''
      };
    }, forDownload);

    if (!picked) return null;
    var isrcMatched = !!(track.isrc && picked.isrc === track.isrc);
    var formats = qobuzFormatOrder(wantTier);

    for (var i = 0; i < formats.length; i++) {
      if (!hasTime(1500)) break;
      var fmt = formats[i];
      var ts = Math.floor(Date.now() / 1000).toString();
      var sigRaw = 'trackgetFileUrlformat_id' + fmt + 'intentstreamtrack_id' + picked.id + ts + cred.appSecret;
      var sig = myspoti.util.md5(sigRaw);
      var fileUrl = QOBUZ_API_BASE + '/track/getFileUrl?request_ts=' + enc(ts) +
        '&request_sig=' + enc(sig) +
        '&track_id=' + enc(picked.id) +
        '&format_id=' + enc(fmt) +
        '&intent=stream';
      var fr = httpGet(fileUrl, headers, 3400);
      if (fr.status === 401 || fr.status === 403) return { authFailed: true, status: fr.status };
      if (!fr.ok || !fr.json || !fr.json.url) continue;
      if (fr.json.sample === true) continue;

      var mime = String(fr.json.mime_type || '').toLowerCase();
      var isMp3 = fmt === 5 || mime.indexOf('mpeg') >= 0;
      var bitDepth = Number(fr.json.bit_depth || (fmt >= 7 ? 24 : 16));
      var sampleRate = fr.json.sampling_rate ? Math.round(Number(fr.json.sampling_rate) * 1000) : 44100;
      if (sampleRate > 768000) sampleRate = Math.round(sampleRate / 1000);
      return {
        format: isMp3 ? 'mp3' : 'flac',
        url: String(fr.json.url),
        bitDepth: isMp3 ? undefined : bitDepth,
        sampleRate: sampleRate,
        kbps: isMp3 ? 320 : undefined,
        provider: label,
        isrcMatched: isrcMatched
      };
    }
    return null;
  }

  function resolveQobuzFromInstances(track, wantTier, forDownload) {
    var userUrls = settingUrlList('qobuz_instances');
    var discUrls = (!aheadMode && settingBool('pool_enabled', true)) ? (getPoolDiscovery(false).qobuz || []) : [];
    var instances = orderHealthyUrls(userUrls.concat(discUrls), 'qobuz_inst').slice(0, aheadMode ? 2 : 4);
    if (!instances.length || !hasTime(2400)) return null;

    var q = track.isrc || ((track.artist ? (track.artist + ' ') : '') + track.title).trim();
    var formats = qobuzFormatOrder(wantTier);

    for (var i = 0; i < instances.length; i++) {
      if (!hasTime(2200)) break;
      var base = instances[i];
      var sr = httpGet(base + '/api/get-music?q=' + enc(q) + '&offset=0', null, 3200);
      if (!sr.ok || !sr.json) {
        markCooldown('qobuz_inst:' + base.toLowerCase(), SOFT_COOLDOWN_MS, 'HTTP ' + sr.status);
        continue;
      }
      var tracksNode = (sr.json.data && sr.json.data.tracks) || sr.json.tracks || sr.json;
      var items = Array.isArray(tracksNode) ? tracksNode : (tracksNode && Array.isArray(tracksNode.items) ? tracksNode.items : []);
      var picked = pickBestCandidate(track, items, function (it) {
        if (!it || !it.id) return null;
        var perf = (it.performer && it.performer.name) || (it.artist && it.artist.name) || it.artist || '';
        return {
          id: String(it.id),
          title: String(it.title || '') + (it.version ? (' (' + it.version + ')') : ''),
          artist: String(perf),
          durationSec: Number(it.duration || 0),
          isrc: it.isrc ? String(it.isrc).toUpperCase() : ''
        };
      }, forDownload);
      if (!picked) continue;

      for (var fIdx = 0; fIdx < formats.length; fIdx++) {
        if (!hasTime(1600)) break;
        var qual = formats[fIdx];
        var dr = httpGet(base + '/api/download-music?track_id=' + enc(picked.id) + '&quality=' + enc(qual), null, 3500);
        if (!dr.ok || !dr.json) continue;
        var streamObj = dr.json.data || dr.json;
        var sUrl = streamObj && (streamObj.url || streamObj.stream_url);
        if (!sUrl || streamObj.sample === true) continue;
        var isMp3 = qual === 5 || /\.mp3(?:\?|$)/i.test(sUrl);
        clearCooldown('qobuz_inst:' + base.toLowerCase());
        return {
          format: isMp3 ? 'mp3' : 'flac',
          url: String(sUrl),
          bitDepth: isMp3 ? undefined : (qual >= 7 ? 24 : 16),
          sampleRate: qual === 27 ? 96000 : 44100,
          kbps: isMp3 ? 320 : undefined,
          provider: 'Qobuz Proxy',
          isrcMatched: !!(track.isrc && picked.isrc === track.isrc)
        };
      }
    }
    return null;
  }

  function resolveQobuzSource(track, wantTier, forDownload) {
    if (!settingBool('qobuz_enabled', true) || !hasTime(2200)) return null;

    // 1. User Qobuz Direct Credentials (built-in App ID / Secret fallback when only User Token is set)
    var uToken = settingStr('qobuz_user_token', '');
    var uAppId = settingStr('qobuz_app_id', '') || QOBUZ_DEFAULT_APP_ID;
    var uSecret = settingStr('qobuz_app_secret', '') || QOBUZ_DEFAULT_SECRET;
    if (uToken) {
      var uRes = resolveQobuzDirectWithCreds(track, {
        appId: uAppId,
        appSecret: uSecret,
        token: uToken
      }, 'Qobuz Account', wantTier, forDownload);
      if ((!uRes || uRes.authFailed) && !settingStr('qobuz_app_id', '') && hasTime(2000)) {
        uRes = resolveQobuzDirectWithCreds(track, {
          appId: QOBUZ_ALT_APP_ID,
          appSecret: uSecret,
          token: uToken
        }, 'Qobuz Account', wantTier, forDownload);
      }
      if (uRes && !uRes.authFailed) return uRes;
    }

    // 2. Cloud Pool Qobuz Accounts
    var poolQ = getPoolAccounts(false).qobuz || [];
    for (var i = 0; i < poolQ.length && i < 3; i++) {
      if (!hasTime(2000)) break;
      var acc = poolQ[i];
      if (isCooledDown('pool.qobuz:' + acc.id)) continue;
      var pRes = resolveQobuzDirectWithCreds(track, acc, 'Qobuz Pool', wantTier, forDownload);
      if (pRes && pRes.authFailed) {
        markCooldown('pool.qobuz:' + acc.id, HARD_COOLDOWN_MS, 'HTTP ' + pRes.status);
        continue;
      }
      if (pRes) return pRes;
    }

    // 3. Qobuz Proxy Instances
    return resolveQobuzFromInstances(track, wantTier, forDownload);
  }

  // ── Source 3: QOBUZ BACKUP (`QobuzBackupProvider.kt` — `mls.kouzu.in`) ──────

  function resolveQobuzBackupSource(track, wantTier, forDownload) {
    if (!settingBool('qobuz_backup_enabled', false) || !hasTime(2400)) return null;
    var rawBase = settingStr('qobuz_backup_url', 'https://mls.kouzu.in');
    var base = stripSlash(rawBase.replace(/mlc-ytify\.kouzu\.in/i, 'mls.kouzu.in'));
    if (!base || isCooledDown('qobuz_backup:' + base.toLowerCase())) return null;

    var muzoHeaders = { 'x-request-source': 'muzo' };
    var q = ((track.artist ? (track.artist + ' ') : '') + track.title).trim();
    var sr = httpGet(base + '/api/search?q=' + enc(q) + '&limit=16', muzoHeaders, 3000);
    if (!sr.ok || !sr.json) {
      markCooldown('qobuz_backup:' + base.toLowerCase(), sr.status === 404 ? HARD_COOLDOWN_MS : SOFT_COOLDOWN_MS, 'HTTP ' + sr.status);
      return null;
    }

    var results = Array.isArray(sr.json) ? sr.json : (sr.json.results || sr.json.items || sr.json.data || []);
    var picked = pickBestCandidate(track, results, function (it) {
      if (!it) return null;
      var id = it.id || it.videoId || '';
      if (!id) return null;
      var artistStr = Array.isArray(it.artists)
        ? it.artists.map(function (a) { return typeof a === 'string' ? a : (a && a.name); }).filter(Boolean).join(', ')
        : String(it.artist || it.author || it.uploader || '');
      return {
        id: String(id),
        title: String(it.title || it.name || ''),
        artist: artistStr,
        durationSec: Number(it.duration || it.lengthSeconds || 0),
        isrc: it.isrc ? String(it.isrc).toUpperCase() : ''
      };
    }, forDownload);

    if (!picked || !hasTime(1800)) return null;

    var st = httpGet(base + '/api/stream?id=' + enc(picked.id), muzoHeaders, 3400);
    if (!st.ok || !st.json) return null;
    var streamUrl = st.json.flac || st.json.lossless || st.json.url || (st.json.data && st.json.data.url) || '';
    if (!streamUrl) return null;

    var probed = probeAudioStream(streamUrl);
    if (!probed) return null;
    clearCooldown('qobuz_backup:' + base.toLowerCase());
    return {
      format: probed.format,
      url: String(streamUrl),
      bitDepth: probed.format === 'flac' ? 16 : undefined,
      sampleRate: 44100,
      kbps: probed.format === 'flac' ? undefined : 256,
      provider: 'Qobuz Backup',
      isrcMatched: !!(track.isrc && picked.isrc === track.isrc)
    };
  }

// ── 07-audio-other.js ──
  // ── Source 4: DEEZER (`DeezerInstances.kt`) ─────────────────────────────────

  function resolveDeezerCatalogTrack(track, forDownload) {
    var cacheKey = 'deezer:' + (track.isrc || (track.artist + ' - ' + track.title));
    if (memCatalogCache[cacheKey]) return memCatalogCache[cacheKey];

    // 1. Exact ISRC lookup on Deezer public API
    if (track.isrc && hasTime(1800)) {
      var rIsrc = httpGet('https://api.deezer.com/2.0/track/isrc:' + enc(track.isrc), null, 2800);
      if (rIsrc.ok && rIsrc.json && rIsrc.json.id && !rIsrc.json.error) {
        var exact = {
          id: String(rIsrc.json.id),
          isrc: String(rIsrc.json.isrc || track.isrc).toUpperCase(),
          isrcMatched: true
        };
        memCatalogCache[cacheKey] = exact;
        return exact;
      }
    }

    // 2. Search fallback on Deezer public API
    if (!hasTime(1800)) return null;
    var q = ((track.artist ? (track.artist + ' ') : '') + track.title).trim();
    var rSearch = httpGet('https://api.deezer.com/search/track?q=' + enc(q) + '&limit=8', null, 2800);
    var list = rSearch.ok && rSearch.json && Array.isArray(rSearch.json.data) ? rSearch.json.data : [];
    var picked = pickBestCandidate(track, list, function (it) {
      if (!it || !it.id) return null;
      return {
        id: String(it.id),
        title: String(it.title || ''),
        artist: (it.artist && it.artist.name) ? String(it.artist.name) : '',
        durationSec: Number(it.duration || 0),
        isrc: it.isrc ? String(it.isrc).toUpperCase() : ''
      };
    }, forDownload);

    if (picked) {
      var res = {
        id: picked.id,
        isrc: picked.isrc || track.isrc || '',
        isrcMatched: !!(track.isrc && picked.isrc === track.isrc)
      };
      memCatalogCache[cacheKey] = res;
      return res;
    }
    return null;
  }

  function resolveDeezerSource(track, wantTier, forDownload) {
    if (!settingBool('deezer_enabled', true) || !hasTime(2200)) return null;
    var userUrls = settingUrlList('deezer_instances');
    var discUrls = (!aheadMode && settingBool('pool_enabled', true)) ? (getPoolDiscovery(false).deezer || []) : [];
    var instances = orderHealthyUrls(userUrls.concat(discUrls), 'deezer_inst').slice(0, aheadMode ? 2 : 4);
    if (!instances.length) return null;

    var cat = resolveDeezerCatalogTrack(track, forDownload);
    if (!cat || (!cat.id && !cat.isrc)) return null;

    for (var i = 0; i < instances.length; i++) {
      if (!hasTime(2000)) break;
      var base = instances[i];
      var candidates = [];
      if (cat.isrc) candidates.push(base + '/stream/?isrc=' + enc(cat.isrc));
      if (cat.id) candidates.push(base + '/stream/' + enc(cat.id));

      for (var c = 0; c < candidates.length; c++) {
        if (!hasTime(1600)) break;
        var target = candidates[c];
        // First inspect with small Range request: instance may return direct audio bytes OR JSON `{ url }`
        var r = httpGet(target, { 'Range': 'bytes=0-511' }, 3400);
        if (!r.ok && r.status !== 206) continue;
        var ct = headerValue(r.headers, 'content-type').toLowerCase();

        if (ct.indexOf('application/json') >= 0 || (r.json && (r.json.url || (r.json.data && r.json.data.url)))) {
          var jObj = r.json;
          if (!jObj && r.text) {
            try { jObj = JSON.parse(r.text); } catch (e) { jObj = null; }
          }
          var indirectUrl = jObj && (jObj.url || jObj.stream_url || (jObj.data && jObj.data.url));
          if (indirectUrl && /^https?:\/\//i.test(indirectUrl)) {
            var probedIndirect = probeAudioStream(indirectUrl);
            if (probedIndirect) {
              clearCooldown('deezer_inst:' + base.toLowerCase());
              return {
                format: probedIndirect.format,
                url: String(indirectUrl),
                bitDepth: probedIndirect.format === 'flac' ? 16 : undefined,
                sampleRate: 44100,
                kbps: probedIndirect.format === 'flac' ? undefined : 320,
                provider: 'Deezer',
                isrcMatched: cat.isrcMatched
              };
            }
          }
          continue;
        }

        var body = r.text || '';
        var fmt = '';
        if (body.indexOf('fLaC') === 0 || ct.indexOf('flac') >= 0) fmt = 'flac';
        else if (body.indexOf('ID3') === 0 || ct.indexOf('mpeg') >= 0 || ct.indexOf('mp3') >= 0) fmt = 'mp3';
        if (fmt) {
          clearCooldown('deezer_inst:' + base.toLowerCase());
          return {
            format: fmt,
            url: target,
            bitDepth: fmt === 'flac' ? 16 : undefined,
            sampleRate: 44100,
            kbps: fmt === 'flac' ? undefined : 320,
            provider: 'Deezer',
            isrcMatched: cat.isrcMatched
          };
        }
      }
      markCooldown('deezer_inst:' + base.toLowerCase(), SOFT_COOLDOWN_MS, 'no playable stream');
    }
    return null;
  }

  // ── Source 5: JIOSAAVN (`SaavnService.kt` — DES-ECB 320 kbps AAC) ───────────

  var SAAVN_API = 'https://www.jiosaavn.com/api.php';

  function resolveJioSaavnSource(track, wantTier, forDownload) {
    if (!settingBool('jiosaavn_enabled', true) || !hasTime(2000)) return null;
    if (isCooledDown('provider:jiosaavn')) return null;

    var q = ((track.artist ? (track.artist + ' ') : '') + track.title).trim();
    var url = SAAVN_API + '?__call=search.getResults&_format=json&_marker=0&api_version=4&ctx=web6dot0&p=1&n=10&q=' + enc(q);
    var r = httpGet(url, {
      'X-Forwarded-For': '49.36.0.1',
      'X-Real-IP': '49.36.0.1',
      'Accept-Language': 'en-IN,en;q=0.9'
    }, 3400);
    if (!r.ok || !r.json) {
      if (r.status >= 500 || r.status === 429) markCooldown('provider:jiosaavn', SOFT_COOLDOWN_MS, 'HTTP ' + r.status);
      return null;
    }

    var results = Array.isArray(r.json.results) ? r.json.results : [];
    var picked = pickBestCandidate(track, results, function (it) {
      if (!it) return null;
      var more = it.more_info || {};
      if (more.rights && String(more.rights.code || '') === '1') return null;
      var encMedia = more.encrypted_media_url || it.encrypted_media_url || '';
      if (!encMedia) return null;
      var artistStr = '';
      if (more.artistMap && Array.isArray(more.artistMap.primary_artists) && more.artistMap.primary_artists.length) {
        artistStr = more.artistMap.primary_artists.map(function (a) { return decodeXmlEntities(a && a.name); }).filter(Boolean).join(', ');
      } else {
        artistStr = decodeXmlEntities(more.music || it.subtitle || '');
      }
      return {
        id: String(it.id || ''),
        title: decodeXmlEntities(it.title || it.song || ''),
        artist: artistStr,
        durationSec: Number(more.duration || it.duration || 0),
        encryptedUrl: String(encMedia),
        has320: String(more['320kbps'] || '').toLowerCase() === 'true'
      };
    }, forDownload);

    if (!picked || !picked.encryptedUrl) return null;

    var decrypted = saavnDecryptUrl(picked.encryptedUrl);
    if (!decrypted || !/^https?:\/\//i.test(decrypted)) return null;

    decrypted = decrypted.replace(/^http:\/\//i, 'https://');
    var wantHigh = wantTier !== 'LOW';
    var urlCandidates = [];
    if (wantHigh && picked.has320) {
      urlCandidates.push({ url: decrypted.replace(/_(?:96|160)\.mp4/i, '_320.mp4'), kbps: 320 });
    }
    var midUrl = /_96\.mp4/i.test(decrypted) ? decrypted.replace(/_96\.mp4/i, '_160.mp4') : decrypted;
    var midKbps = /_320\.mp4/i.test(midUrl) ? 320 : 160;
    if (!urlCandidates.length || urlCandidates[0].url !== midUrl) {
      urlCandidates.push({ url: midUrl, kbps: midKbps });
    }
    if (decrypted !== midUrl) {
      urlCandidates.push({ url: decrypted, kbps: 96 });
    }

    for (var ui = 0; ui < urlCandidates.length; ui++) {
      if (!hasTime(1500)) break;
      var cand = urlCandidates[ui];
      var saavnProbed = probeAudioStream(cand.url, null, 3200);
      if (saavnProbed) {
        return {
          format: 'm4a',
          url: cand.url,
          sampleRate: 44100,
          kbps: cand.kbps,
          sizeHint: saavnProbed.totalBytes || undefined,
          provider: 'JioSaavn',
          isrcMatched: false
        };
      }
    }
    return null;
  }

  // ── Source 6: QQ MUSIC (`QqMusicApi.kt` + `QqMusicAudioProvider.kt`) ────────

  var QQ_MUSICU_URL = 'https://u.y.qq.com/cgi-bin/musicu.fcg';

  function qqGuid() {
    var g = myspoti.storage.get('qq.guid');
    if (!g) {
      g = String(Math.floor(1000000000 + Math.random() * 8999999999));
      myspoti.storage.set('qq.guid', g);
    }
    return String(g);
  }

  function qqComm() {
    var uin = settingStr('qqmusic_uin', '0').replace(/\D/g, '') || '0';
    var key = settingStr('qqmusic_key', '');
    var comm = {
      ct: 19,
      cv: 1859,
      uin: uin,
      format: 'json'
    };
    if (key) {
      comm.authst = key;
      comm.qq = uin;
    }
    return comm;
  }

  function resolveQqMusicSource(track, wantTier, forDownload) {
    if (!settingBool('qqmusic_enabled', true) || !hasTime(2400)) return null;
    if (isCooledDown('provider:qqmusic')) return null;

    var q = ((track.artist ? (track.artist + ' ') : '') + track.title).trim();
    var searchPayload = {
      comm: qqComm(),
      req: {
        module: 'music.search.SearchCgiService',
        method: 'DoSearchForQQMusicDesktop',
        param: {
          grp: 1,
          num_per_page: 8,
          page_num: 1,
          query: q,
          search_type: 0
        }
      }
    };
    var sr = httpPost(QQ_MUSICU_URL, searchPayload, {
      'Referer': 'https://y.qq.com/',
      'Origin': 'https://y.qq.com'
    }, 3200);
    if (!sr.ok || !sr.json || !sr.json.req || !sr.json.req.data || !sr.json.req.data.body) return null;

    var songList = (sr.json.req.data.body.song && Array.isArray(sr.json.req.data.body.song.list))
      ? sr.json.req.data.body.song.list : [];

    var picked = pickBestCandidate(track, songList, function (it) {
      if (!it || !it.mid) return null;
      var singers = Array.isArray(it.singer)
        ? it.singer.map(function (s) { return s && s.name; }).filter(Boolean).join(', ')
        : '';
      return {
        mid: String(it.mid),
        mediaMid: (it.file && it.file.media_mid) ? String(it.file.media_mid) : String(it.mid),
        title: String(it.title || it.name || ''),
        artist: singers,
        durationSec: Number(it.interval || 0)
      };
    }, forDownload);

    if (!picked || !hasTime(1800)) return null;

    var resId = picked.mediaMid || (picked.mid + picked.mid);
    var tiers = (wantTier === 'HIGH' || wantTier === 'small')
      ? [
          { prefix: 'M800', ext: '.mp3', format: 'mp3', kbps: 320 },
          { prefix: 'C400', ext: '.m4a', format: 'm4a', kbps: 192 },
          { prefix: 'M500', ext: '.mp3', format: 'mp3', kbps: 128 }
        ]
      : [
          { prefix: 'F000', ext: '.flac', format: 'flac', bitDepth: 16 },
          { prefix: 'M800', ext: '.mp3', format: 'mp3', kbps: 320 },
          { prefix: 'C400', ext: '.m4a', format: 'm4a', kbps: 192 },
          { prefix: 'M500', ext: '.mp3', format: 'mp3', kbps: 128 }
        ];

    var uin = settingStr('qqmusic_uin', '0').replace(/\D/g, '') || '0';
    var filenames = tiers.map(function (t) { return t.prefix + resId + t.ext; });
    var songmids = tiers.map(function () { return picked.mid; });
    var songtypes = tiers.map(function () { return 0; });

    var vkeyPayload = {
      comm: qqComm(),
      req_0: {
        module: 'music.vkey.GetVkey',
        method: 'UrlGetVkey',
        param: {
          uin: uin,
          guid: qqGuid(),
          songmid: songmids,
          filename: filenames,
          songtype: songtypes,
          ctx: 0,
          loginflag: 1,
          platform: '20'
        }
      }
    };

    var vr = httpPost(QQ_MUSICU_URL, vkeyPayload, {
      'Referer': 'https://y.qq.com/',
      'Origin': 'https://y.qq.com'
    }, 3200);
    var vData = vr.ok && vr.json && vr.json.req_0 && vr.json.req_0.data;
    if (!vData || !Array.isArray(vData.midurlinfo)) return null;

    var sipList = Array.isArray(vData.sip) ? vData.sip : [];
    var hostBase = stripSlash(sipList[0] || 'https://isure.stream.qqmusic.qq.com').replace(/^http:\/\//i, 'https://');

    for (var i = 0; i < vData.midurlinfo.length && i < tiers.length; i++) {
      var info = vData.midurlinfo[i];
      var purl = info && info.purl ? String(info.purl) : '';
      if (!purl) continue;
      // Reject encrypted QMC containers (.mflac, .mgg) since Myspoti requires plain audio
      if (/\.(?:mflac|mgg|mmp4|mnac)/i.test(purl)) continue;
      var tier = tiers[i];
      var fullUrl = /^https?:\/\//i.test(purl) ? purl : (hostBase + '/' + purl.replace(/^\/+/, ''));
      var qqProbed = probeAudioStream(fullUrl, null, 3000);
      if (!qqProbed) continue;
      return {
        format: tier.format,
        url: fullUrl,
        bitDepth: tier.bitDepth,
        sampleRate: 44100,
        kbps: tier.kbps,
        sizeHint: qqProbed.totalBytes || undefined,
        provider: 'QQ Music',
        isrcMatched: false
      };
    }
    return null;
  }

  // ── Source 7: AMAZON MUSIC (`AmazonAudioProvider.kt` — Proxy Instances) ─────

  function resolveAmazonSource(track, wantTier, forDownload) {
    if (!settingBool('amazon_enabled', true) || !hasTime(2200)) return null;
    var userUrls = settingUrlList('amazon_instances');
    var poolAmz = (!aheadMode && settingBool('pool_enabled', true)) ? (getPoolAccounts(false).amazon || []) : [];

    var entries = userUrls.map(function (u) { return { baseUrl: u, bypassToken: '', turnstileJwt: '' }; });
    for (var p = 0; p < poolAmz.length; p++) {
      if (poolAmz[p] && poolAmz[p].baseUrl) entries.push(poolAmz[p]);
    }
    if (!entries.length) return null;

    var q = track.isrc || ((track.artist ? (track.artist + ' ') : '') + track.title).trim();
    var qual = (wantTier === 'HIGH' || wantTier === 'small') ? 'HIGH' : 'ULTRA_HD';

    for (var i = 0; i < entries.length && i < 3; i++) {
      if (!hasTime(2000)) break;
      var inst = entries[i];
      var base = stripSlash(inst.baseUrl);
      if (isCooledDown('amazon_inst:' + base.toLowerCase())) continue;

      var headers = {};
      if (inst.turnstileJwt && (!inst.expiresAt || inst.expiresAt > Date.now())) {
        headers['X-Turnstile-JWT'] = inst.turnstileJwt;
      }
      var tokenParam = inst.bypassToken ? ('&bypass_token=' + enc(inst.bypassToken)) : '';
      var endpoints = [
        base + '/api/v2/track/?q=' + enc(q) + '&intent=stream&quality=' + enc(qual) + tokenParam,
        base + '/api/track/?q=' + enc(q) + '&quality=' + enc(qual) + tokenParam
      ];

      for (var eIdx = 0; eIdx < endpoints.length; eIdx++) {
        if (!hasTime(1600)) break;
        var r = httpGet(endpoints[eIdx], headers, 3400);
        if (!r.ok || !r.json) continue;
        var d = r.json.data || r.json;
        // Skip CENC-encrypted streams (`decryption_key` non-empty) since Myspoti plays plain audio
        if (d.decryption_key || d.decryptionKey) continue;
        var sUrl = d.stream_url || d.streamUrl || d.url || '';
        if (!sUrl || !/^https?:\/\//i.test(sUrl)) continue;
        var probed = probeAudioStream(sUrl);
        if (!probed) continue;
        clearCooldown('amazon_inst:' + base.toLowerCase());
        return {
          format: probed.format,
          url: String(sUrl),
          bitDepth: probed.format === 'flac' ? Number(d.bit_depth || 24) : undefined,
          sampleRate: Number(d.sample_rate || 44100),
          kbps: probed.format === 'flac' ? undefined : 256,
          provider: 'Amazon Music',
          isrcMatched: !!(track.isrc && d.isrc && String(d.isrc).toUpperCase() === track.isrc)
        };
      }
      markCooldown('amazon_inst:' + base.toLowerCase(), SOFT_COOLDOWN_MS, 'unavailable');
    }
    return null;
  }

  // ── Source 8: YOUTUBE MUSIC (`YTPlayerUtils.kt` InnerTube + Piped/Invidious) ─

  function parseYtDurationSec(txt) {
    var m = /(\d+):(\d{2})(?::(\d{2}))?/.exec(String(txt || ''));
    if (!m) return 0;
    if (m[3] !== undefined) return parseInt(m[1], 10) * 3600 + parseInt(m[2], 10) * 60 + parseInt(m[3], 10);
    return parseInt(m[1], 10) * 60 + parseInt(m[2], 10);
  }

  function extractYtSearchItems(node, out) {
    if (!node || typeof node !== 'object' || out.length >= 12) return;
    if (Array.isArray(node)) {
      for (var i = 0; i < node.length; i++) extractYtSearchItems(node[i], out);
      return;
    }
    var r = node.musicResponsiveListItemRenderer;
    if (r) {
      var vid = (r.playlistItemData && r.playlistItemData.videoId) || '';
      var cols = Array.isArray(r.flexColumns) ? r.flexColumns : [];
      var titleRuns = cols[0] && cols[0].musicResponsiveListItemFlexColumnRenderer &&
        cols[0].musicResponsiveListItemFlexColumnRenderer.text &&
        cols[0].musicResponsiveListItemFlexColumnRenderer.text.runs;
      var subRuns = cols[1] && cols[1].musicResponsiveListItemFlexColumnRenderer &&
        cols[1].musicResponsiveListItemFlexColumnRenderer.text &&
        cols[1].musicResponsiveListItemFlexColumnRenderer.text.runs;
      var title = Array.isArray(titleRuns) ? titleRuns.map(function (x) { return x && x.text; }).join('') : '';
      var artistParts = [];
      var durSec = 0;
      if (Array.isArray(subRuns)) {
        for (var s = 0; s < subRuns.length; s++) {
          var t = String((subRuns[s] && subRuns[s].text) || '').trim();
          if (!t || t === '•' || t === '·' || /^song$/i.test(t) || /^brano$/i.test(t)) continue;
          if (/^\d+:\d{2}(?::\d{2})?$/.test(t)) durSec = parseYtDurationSec(t);
          else if (!artistParts.length) artistParts.push(t);
        }
      }
      if (vid && title) {
        out.push({ id: String(vid), title: title, artist: artistParts.join(', '), durationSec: durSec });
      }
      return;
    }
    for (var k in node) {
      if (Object.prototype.hasOwnProperty.call(node, k)) extractYtSearchItems(node[k], out);
    }
  }

  function resolveYoutubeVideoId(track, forDownload) {
    var cacheKey = 'ytvid:' + (track.id || (track.artist + ' - ' + track.title));
    if (memCatalogCache[cacheKey]) return memCatalogCache[cacheKey];
    if (!hasTime(1600)) return '';

    var sl = resolveSonglinkLinks(track);
    if (sl && sl.videoId) {
      memCatalogCache[cacheKey] = sl.videoId;
      return sl.videoId;
    }

    var q = ((track.artist ? (track.artist + ' ') : '') + track.title).trim();
    var body = {
      context: {
        client: {
          clientName: 'WEB_REMIX',
          clientVersion: '1.20260213.01.00',
          hl: 'it',
          gl: 'IT'
        }
      },
      query: q,
      // "EgWKAQIIAWoKEAkQBRAKEAMQBA==" = YouTube Music Songs filter chip
      params: 'EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D'
    };

    var r = httpPost('https://music.youtube.com/youtubei/v1/search?prettyPrint=false', body, {
      'Origin': 'https://music.youtube.com',
      'Referer': 'https://music.youtube.com/'
    }, 2800);
    if (!r.ok || !r.text) return '';

    if (r.json) {
      var ytItems = [];
      extractYtSearchItems(r.json, ytItems);
      var picked = pickBestCandidate(track, ytItems, function (it) { return it; }, forDownload);
      if (picked && picked.id) {
        memCatalogCache[cacheKey] = picked.id;
        return picked.id;
      }
    }

    var vidMatch = /"videoId"\s*:\s*"([A-Za-z0-9_-]{11})"/.exec(r.text);
    if (vidMatch && vidMatch[1]) {
      memCatalogCache[cacheKey] = vidMatch[1];
      return vidMatch[1];
    }
    return '';
  }

  function resolveYoutubeInnerTubeStream(videoId, forDownload) {
    if (!videoId || !hasTime(2200) || isCooledDown('provider:yt_innertube')) return null;

    var ytHeaders = {
      'Content-Type': 'application/json',
      'Origin': 'https://music.youtube.com',
      'Referer': 'https://music.youtube.com/'
    };
      var reqs = [
      {
        url: 'https://music.youtube.com/youtubei/v1/player?prettyPrint=false',
        method: 'POST',
        headers: ytHeaders,
        timeout: 3200,
        body: JSON.stringify({
          videoId: videoId,
          context: {
            client: {
              clientName: 'ANDROID_VR',
              clientVersion: '1.65.10',
              osName: 'Android',
              osVersion: '12L',
              deviceMake: 'Oculus',
              deviceModel: 'Quest 3',
              androidSdkVersion: '32',
              gl: 'IT',
              hl: 'it'
            }
          }
        })
      },
      {
        url: 'https://music.youtube.com/youtubei/v1/player?prettyPrint=false',
        method: 'POST',
        headers: ytHeaders,
        timeout: 3200,
        body: JSON.stringify({
          videoId: videoId,
          context: {
            client: {
              clientName: 'IOS',
              clientVersion: '20.10.4',
              osName: 'iPhone',
              osVersion: '18.3.1.22D72',
              deviceMake: 'Apple',
              deviceModel: 'iPhone16,2',
              gl: 'IT',
              hl: 'it'
            }
          }
        })
      },
      {
        url: 'https://music.youtube.com/youtubei/v1/player?prettyPrint=false',
        method: 'POST',
        headers: ytHeaders,
        timeout: 3200,
        body: JSON.stringify({
          videoId: videoId,
          context: {
            client: {
              clientName: 'VISIONOS',
              clientVersion: '0.1',
              osName: 'visionOS',
              osVersion: '1.3.21O771',
              deviceMake: 'Apple',
              deviceModel: 'RealityDevice14,1',
              gl: 'IT',
              hl: 'it'
            }
          }
        })
      }
    ];

    var resps = httpBatch(reqs, 3400);
    var botBlocked = 0;
    for (var i = 0; i < resps.length; i++) {
      var r = resps[i];
      if (!r || !r.ok || !r.json) continue;
      var ps = r.json.playabilityStatus || {};
      if (ps.status === 'LOGIN_REQUIRED' || ps.status === 'UNPLAYABLE') {
        botBlocked++;
        continue;
      }
      var adaptive = (r.json.streamingData && Array.isArray(r.json.streamingData.adaptiveFormats))
        ? r.json.streamingData.adaptiveFormats : [];
      var audioFmts = adaptive.filter(function (f) {
        if (!f || !f.url) return false;
        var mt = String(f.mimeType || '').toLowerCase();
        if (mt.indexOf('audio/') !== 0) return false;
        if (forDownload && mt.indexOf('mp4') < 0 && mt.indexOf('m4a') < 0) return false;
        return true;
      });
      audioFmts.sort(function (a, b) {
        var aMp4 = String(a.mimeType || '').toLowerCase().indexOf('mp4') >= 0 ? 1 : 0;
        var bMp4 = String(b.mimeType || '').toLowerCase().indexOf('mp4') >= 0 ? 1 : 0;
        if (aMp4 !== bMp4) return bMp4 - aMp4;
        return Number(b.bitrate || 0) - Number(a.bitrate || 0);
      });
      if (audioFmts[0] && audioFmts[0].url && hasTime(1400)) {
        var chosen = audioFmts[0];
        var probed = probeAudioStream(String(chosen.url), null, 2800);
        if (probed) {
          clearCooldown('provider:yt_innertube');
          var isWebm = probed.format === 'webm' && !forDownload;
          return {
            format: isWebm ? 'webm' : 'm4a',
            url: String(chosen.url),
            sampleRate: parseInt(String(chosen.audioSampleRate || '44100'), 10) || 44100,
            kbps: Math.round(Number(chosen.bitrate || 128000) / 1000) || 128,
            sizeHint: parseInt(String(chosen.contentLength || probed.totalBytes || '0'), 10) || undefined,
            provider: 'YouTube Music',
            isrcMatched: false
          };
        }
      }
    }

    if (botBlocked === resps.length && resps.length > 0) {
      markCooldown('provider:yt_innertube', SOFT_COOLDOWN_MS, 'bot-gate');
    }
    return null;
  }

  function resolveYoutubeSource(track, wantTier, forDownload) {
    if (!settingBool('youtube_enabled', true) || !hasTime(2200)) return null;

    var videoId = resolveYoutubeVideoId(track, forDownload);
    if (!videoId) return null;

    // 1. Native InnerTube player clients (`ANDROID_VR` 1.65 + `IOS` + `VISIONOS`)
    var innerRes = resolveYoutubeInnerTubeStream(videoId, forDownload);
    if (innerRes) return innerRes;

    // 2. User-configured Piped / Invidious instances
    var instances = orderHealthyUrls(settingUrlList('piped_instances'), 'piped_inst').slice(0, 3);
    if (!instances.length) return null;

    for (var i = 0; i < instances.length; i++) {
      if (!hasTime(1800)) break;
      var base = instances[i];
      var r = httpGet(base + '/streams/' + enc(videoId), null, 3400);
      var streams = [];
      if (r.ok && r.json && Array.isArray(r.json.audioStreams)) {
        streams = r.json.audioStreams;
      } else if (hasTime(1600)) {
        var inv = httpGet(base + '/api/v1/videos/' + enc(videoId), null, 3400);
        if (inv.ok && inv.json && Array.isArray(inv.json.adaptiveFormats)) {
          streams = inv.json.adaptiveFormats;
        }
      }
      if (!streams.length) {
        markCooldown('piped_inst:' + base.toLowerCase(), SOFT_COOLDOWN_MS, 'no audioStreams');
        continue;
      }
      var m4aStreams = streams.filter(function (s) {
        var mt = String((s && (s.mimeType || s.type)) || '').toLowerCase();
        return s && s.url && (mt.indexOf('mp4') >= 0 || mt.indexOf('m4a') >= 0 || mt.indexOf('aac') >= 0);
      });
      m4aStreams.sort(function (a, b) {
        return Number(b.bitrate || 0) - Number(a.bitrate || 0);
      });
      if (m4aStreams[0] && m4aStreams[0].url) {
        var pStream = probeAudioStream(String(m4aStreams[0].url), null, 2800);
        if (!pStream) continue;
        clearCooldown('piped_inst:' + base.toLowerCase());
        return {
          format: 'm4a',
          url: String(m4aStreams[0].url),
          sampleRate: 44100,
          kbps: Math.round(Number(m4aStreams[0].bitrate || 128000) / 1000) || 128,
          sizeHint: pStream.totalBytes || undefined,
          provider: 'YouTube / Piped',
          isrcMatched: false
        };
      }
    }
    return null;
  }

  // ── Source 9: NETEASE HI-RES / LOSSLESS FLAC (Zero-Config Primary FLAC) ─────

  var NETEASE_SEARCH_URL = 'https://music.163.com/api/cloudsearch/pc';
  var GDSTUDIO_API_URL = 'https://music-api.gdstudio.xyz/api.php';

  function mapNeteaseCloudItem(it) {
    if (!it || !it.id) return null;
    var artists = Array.isArray(it.ar)
      ? it.ar.map(function (a) { return a && a.name; }).filter(Boolean).join(', ')
      : (Array.isArray(it.artists)
        ? it.artists.map(function (a) { return typeof a === 'string' ? a : (a && a.name); }).filter(Boolean).join(', ')
        : '');
    var durMs = Math.max(0, Number(it.dt || it.duration || 0));
    return {
      id: String(it.id),
      title: String(it.name || it.title || ''),
      artist: artists,
      album: (it.al && it.al.name) ? String(it.al.name) : String(it.album || ''),
      durationMs: durMs,
      durationSec: durMs > 0 ? Math.round(durMs / 1000) : 0,
      isrc: ''
    };
  }

  function rankTopCandidates(track, rawList, mapper, forDownload, limit) {
    if (!Array.isArray(rawList) || !rawList.length) return [];
    var scored = [];
    var seen = {};
    for (var i = 0; i < rawList.length; i++) {
      var mapped = mapper ? mapper(rawList[i]) : rawList[i];
      if (!mapped || !mapped.id || seen[mapped.id]) continue;
      var sc = scoreCandidate(track, mapped, forDownload);
      if (sc > 0) {
        seen[mapped.id] = 1;
        mapped._score = sc;
        scored.push(mapped);
      }
    }
    scored.sort(function (a, b) { return b._score - a._score; });
    return scored.slice(0, limit || 2);
  }

  function fetchGdStudioNeteaseUrl(songId, brCode) {
    var u = GDSTUDIO_API_URL + '?types=url&source=netease&id=' + enc(songId) + '&br=' + enc(brCode);
    var r = httpGet(u, { 'Accept': 'application/json' }, 3400);
    if ((!r.ok || !r.json) && (r.status === 0 || r.status >= 500) && hasTime(2600)) {
      r = httpGet(u, { 'Accept': 'application/json' }, 3400);
    }
    return r;
  }

  function resolveNeteaseSource(track, wantTier, forDownload) {
    if (!settingBool('netease_enabled', true) || !hasTime(2400)) return null;
    if (isCooledDown('provider:netease_gd')) return null;

    var rawQuery = ((track.title ? (track.title + ' ') : '') + (track.artist || '')).trim();
    if (!rawQuery) return null;

    var isrcCacheKey = 'isrc:' + (track.uri || rawQuery.toLowerCase());
    if (!track.isrc && memCatalogCache[isrcCacheKey]) {
      track.isrc = memCatalogCache[isrcCacheKey];
    }

    var searchUrl = NETEASE_SEARCH_URL + '?s=' + enc(rawQuery) + '&type=1&limit=10&offset=0';
    var sr = null;
    if (forDownload && !track.isrc) {
      var dzUrl = 'https://api.deezer.com/search/track?q=' + enc((track.artist ? (track.artist + ' ') : '') + track.title) + '&limit=5';
      var batch = httpBatch([
        { url: searchUrl, headers: { 'Accept': 'application/json' }, timeout: 2800 },
        { url: dzUrl, headers: { 'Accept': 'application/json' }, timeout: 2400 }
      ], 3000);
      sr = batch[0];
      var dzResp = batch[1];
      if (dzResp && dzResp.ok && dzResp.json && Array.isArray(dzResp.json.data)) {
        var dzHit = pickBestCandidate(track, dzResp.json.data, function (d) {
          if (!d || !d.id) return null;
          return {
            id: String(d.id),
            title: String(d.title || ''),
            artist: (d.artist && d.artist.name) ? String(d.artist.name) : '',
            durationSec: Number(d.duration || 0),
            isrc: d.isrc ? String(d.isrc).toUpperCase() : ''
          };
        }, forDownload);
        if (dzHit && dzHit.isrc) {
          track.isrc = dzHit.isrc;
          memCatalogCache[isrcCacheKey] = dzHit.isrc;
        }
      }
    } else {
      sr = httpGet(searchUrl, { 'Accept': 'application/json' }, 2800);
    }

    var rawSongs = (sr && sr.ok && sr.json && sr.json.result && Array.isArray(sr.json.result.songs))
      ? sr.json.result.songs : [];
    var topCandidates = rankTopCandidates(track, rawSongs, mapNeteaseCloudItem, forDownload, 2);

    // Cleaned query fallback (strips `(feat. ...)` / `- Remastered ...`)
    if (!topCandidates.length && hasTime(3000)) {
      var altQ = cleanTrackSearchQuery(track.artist, track.title);
      if (altQ && altQ.toLowerCase() !== rawQuery.toLowerCase()) {
        var sr2 = httpGet(NETEASE_SEARCH_URL + '?s=' + enc(altQ) + '&type=1&limit=10&offset=0', {
          'Accept': 'application/json'
        }, 2600);
        var altSongs = (sr2.ok && sr2.json && sr2.json.result && Array.isArray(sr2.json.result.songs))
          ? sr2.json.result.songs : [];
        topCandidates = rankTopCandidates(track, altSongs, mapNeteaseCloudItem, forDownload, 2);
      }
    }

    // Secondary search mirror via GDStudio if music.163.com search was blocked
    if (!topCandidates.length && (!sr || !sr.ok) && hasTime(3000)) {
      var gdsSearch = httpGet(
        GDSTUDIO_API_URL + '?types=search&source=netease&name=' + enc(rawQuery) + '&count=8&pages=1',
        { 'Accept': 'application/json' },
        2800
      );
      if (gdsSearch.ok && Array.isArray(gdsSearch.json)) {
        topCandidates = rankTopCandidates(track, gdsSearch.json, mapNeteaseCloudItem, forDownload, 2);
      }
    }

    if (!topCandidates.length) return null;

    var wantLossy = wantTier === 'HIGH' || wantTier === 'small';
    var brParam = wantLossy ? '320' : '999';

    for (var cIdx = 0; cIdx < topCandidates.length; cIdx++) {
      if (!hasTime(2000)) break;
      var cand = topCandidates[cIdx];
      var ur = fetchGdStudioNeteaseUrl(cand.id, brParam);
      if (!ur || !ur.ok || !ur.json) {
        if (ur && (ur.status === 401 || ur.status === 403)) {
          markCooldown('provider:netease_gd', SOFT_COOLDOWN_MS, 'HTTP ' + ur.status);
          break;
        }
        continue;
      }

      var streamUrl = String(ur.json.url || '').trim().replace(/^http:\/\//i, 'https://');
      if (!streamUrl || !/^https:\/\//i.test(streamUrl)) continue;

      var brKbps = Number(ur.json.br || 0);
      var byteSize = Number(ur.json.size || 0);

      // Guard against 30-second VIP trial clips and mismatched audio durations using exact byteSize & bitrate
      if (byteSize > 0 && brKbps > 0) {
        var estSec = (byteSize * 8) / (brKbps * 1000);
        if (track.durationSec >= 65 && estSec > 0 && estSec < 48) {
          continue;
        }
        if (forDownload && track.durationSec > 0 && estSec > 0) {
          var dDiff = estSec - track.durationSec;
          if (dDiff < -5.2 || dDiff > 15.2) continue;
        }
      } else if (byteSize > 0 && track.durationSec >= 75 && byteSize < 1400000) {
        continue;
      }

      var probed = probeAudioStream(streamUrl, null, 2800);
      if (!probed) continue;
      // Note: NetEase CDN sends `Content-Type: audio/mpeg` even on genuine `fLaC` streams;
      // `probeAudioStream` checks `body.indexOf('fLaC') === 0` first so FLAC is detected accurately.
      var fmt = probed.format;
      if (fmt !== 'flac' && fmt !== 'mp3' && fmt !== 'm4a') continue;

      clearCooldown('provider:netease_gd');
      var isHiRes = fmt === 'flac' && brKbps >= 1250;
      var durVerified = !!(track.durationSec > 0 && cand.durationSec > 0 && Math.abs(cand.durationSec - track.durationSec) <= 2);

      return {
        format: fmt,
        url: streamUrl,
        bitDepth: fmt === 'flac' ? (isHiRes ? 24 : 16) : undefined,
        sampleRate: fmt === 'flac' ? (isHiRes ? 48000 : 44100) : 44100,
        kbps: fmt === 'flac' ? (brKbps || undefined) : (brKbps || 320),
        sizeHint: byteSize || probed.totalBytes || undefined,
        durationMs: cand.durationMs || track.durationMs || undefined,
        provider: isHiRes ? 'NetEase Hi-Res' : 'NetEase Lossless',
        isrcMatched: !!(track.isrc && durVerified)
      };
    }

    return null;
  }

// ── 09-hooks-ui.js ──
  // ── Multi-Source Audio & Download Coordinator + Myspoti Hooks & Control Page ─

  var DEFAULT_AUDIO_ORDER = 'netease,tidal,qobuz,deezer,qobuz_backup,jiosaavn,qqmusic,amazon,youtube';

  var AUDIO_DISPATCH = {
    'netease': resolveNeteaseSource,
    'tidal': resolveTidalSource,
    'qobuz': resolveQobuzSource,
    'qobuz_backup': resolveQobuzBackupSource,
    'deezer': resolveDeezerSource,
    'jiosaavn': resolveJioSaavnSource,
    'qqmusic': resolveQqMusicSource,
    'amazon': resolveAmazonSource,
    'youtube': resolveYoutubeSource
  };

  function safeNotify(msg) {
    // Internal extension notices stay out of the notification shade.
    appendDiag('notice', String(msg).substring(0, 190));
  }

  function effectiveAudioOrder() {
    var list = settingList('audio_priority', DEFAULT_AUDIO_ORDER);
    var lower = list.map(function (x) { return String(x).toLowerCase(); });
    // Ensure updates from v1.0/v1.1 with a previously saved `audio_priority` still get zero-config NetEase FLAC
    if (settingBool('netease_enabled', true) && lower.indexOf('netease') < 0) {
      var hasPersonalTidal = !!(getActiveUserTidalSession() || (getPoolAccounts(false).tidal || []).length);
      if (hasPersonalTidal && lower.indexOf('tidal') >= 0) {
        lower.splice(lower.indexOf('tidal') + 1, 0, 'netease');
      } else {
        lower.unshift('netease');
      }
    }
    return lower;
  }

  function recordResolvedTrackInfo(track, media) {
    if (!track || !track.uri || !media) return;
    try {
      var book = myspoti.storage.get('cache.trackinfo');
      if (!book || typeof book !== 'object') book = {};
      var keys = Object.keys(book);
      if (keys.length > 40) {
        for (var i = 0; i < keys.length - 30; i++) delete book[keys[i]];
      }
      book[track.uri] = {
        provider: media.provider || 'Lossless FLAC',
        format: String(media.format || '').toUpperCase(),
        bitDepth: media.bitDepth || 0,
        sampleRate: media.sampleRate || 0,
        kbps: media.kbps || 0,
        isrcMatched: !!media.isrcMatched,
        isrc: track.isrc || '',
        at: Date.now()
      };
      myspoti.storage.set('cache.trackinfo', book);
    } catch (e) {}
  }

  function resolveAudioCandidates(rawTrack, wantTier, forDownload, maxCount, skipCode, traceOut) {
    var track = normalizeTrackInput(rawTrack);
    if (!track.title) return [];

    var order = effectiveAudioOrder();
    var wantLossless = wantTier !== 'HIGH' && wantTier !== 'small';
    var results = [];
    var fallbackLossy = [];

    for (var i = 0; i < order.length; i++) {
      if (!hasTime(1500)) {
        if (traceOut) traceOut.push('budget');
        break;
      }
      var code = order[i];
      var fn = AUDIO_DISPATCH[code];
      if (!fn) continue;
      if (skipCode && code === skipCode) {
        if (traceOut) traceOut.push(code + ':skip-retry');
        continue;
      }
      // In prefetch (`ahead`) mode, skip heavy multi-hop fallbacks if budget is tight
      if (aheadMode && !hasTime(2800) && (code === 'youtube' || code === 'amazon')) continue;

      var media = null;
      var tStart = Date.now();
      try {
        media = fn(track, wantTier, forDownload);
      } catch (e) {
        media = null;
        if (traceOut) traceOut.push(code + ':err');
      }
      var dt = Date.now() - tStart;

      if (!media) {
        if (traceOut && dt >= 40) traceOut.push(code + ':0(' + dt + 'ms)');
        continue;
      }

      media._code = code;
      var isLossless = media.format === 'flac' || media.format === 'dash-flac';
      if (wantLossless && !isLossless) {
        if (traceOut) traceOut.push(code + ':lossy');
        fallbackLossy.push(media);
        continue;
      }
      if (!wantLossless && isLossless && forDownload) {
        fallbackLossy.push(media);
        continue;
      }

      if (traceOut) traceOut.push(code + ':ok(' + dt + 'ms)');
      results.push(media);
      if (results.length >= (maxCount || 1)) break;
    }

    var combined = results.concat(fallbackLossy);
    combined.sort(function (a, b) {
      if (wantLossless) return qualityTierRank(b) - qualityTierRank(a);
      return qualityTierRank(a) - qualityTierRank(b);
    });
    return combined.slice(0, maxCount || 5);
  }

  // ── Hook: `audio-source` (15s host limit -> 13.2s / 9.5s ahead budget) ──────

  myspoti.provide('audio-source', function (input) {
    if (!settingBool('enable_audio_stream', true)) return null;
    var isAhead = !!(input && input.ahead);
    return withBudget(isAhead ? BUDGET.ahead : BUDGET.audio, isAhead, function () {
      var t0 = Date.now();
      var track = normalizeTrackInput(input);
      if (!track.title) return null;

      var wantTier = settingStr('preferred_quality', 'HI_RES_LOSSLESS');
      var trackKey = track.id || track.uri || (track.artist + '::' + track.title);
      var cacheKey = trackKey + '::' + wantTier;

      if (isAhead) {
        var cached = memStreamCache[cacheKey];
        if (cached && cached.until > Date.now()) {
          return cached.stream;
        }
      } else {
        delete memStreamCache[cacheKey];
      }

      // If Myspoti re-asks non-ahead within 25s (`again = true` because ExoPlayer failed to open URL),
      // skip the provider we just served so we fail over cleanly to the next working source.
      var skipCode = '';
      if (!isAhead) {
        var prev = recentStreamPick[trackKey];
        if (prev && (Date.now() - prev.at) < 25000) {
          skipCode = prev.code || '';
        }
      }

      var trace = [];
      var candidates = resolveAudioCandidates(track, wantTier, false, 1, skipCode, trace);
      var media = candidates[0];
      var elapsed = Date.now() - t0;
      var label = (track.artist ? (track.artist + ' - ') : '') + track.title;

      if (!media) {
        var missSummary = label + ' [' + (trace.length ? trace.join(', ') : 'nessuna fonte attiva') + ']';
        if (!isAhead) appendDiag('audio-miss', missSummary);
        log('audio-miss (' + elapsed + 'ms): ' + missSummary);
        return hostHas('results') ? { outcome: 'not-found' } : null;
      }

      var stream = toStreamSource(media, track);
      if (!stream) return null;

      if (isAhead) {
        memStreamCache[cacheKey] = {
          stream: stream,
          until: Date.now() + 60000
        };
      } else {
        recentStreamPick[trackKey] = {
          code: media._code || '',
          at: Date.now()
        };
      }

      recordResolvedTrackInfo(track, media);
      var hitSummary = label + ' -> ' + describeMediaSource(media) + ' (' + elapsed + 'ms)';
      appendDiag(isAhead ? 'prefetch' : 'audio', hitSummary);
      log((isAhead ? 'prefetch' : 'audio') + ': ' + hitSummary);
      return stream;
    });
  });

  // ── Hook: `download-source` (30s host limit -> 26.5s budget) ────────────────

  myspoti.provide('download-source', function (input) {
    return withBudget(BUDGET.download, false, function () {
      var t0 = Date.now();
      var track = normalizeTrackInput(input);
      if (!track.title) return [];
      var reqQual = String((input && input.quality) || 'hi-res').toLowerCase();
      var wantTier = reqQual === 'small' ? 'HIGH' : (reqQual === 'cd' ? 'LOSSLESS' : 'HI_RES_LOSSLESS');

      var trace = [];
      var candidates = resolveAudioCandidates(track, wantTier, true, 1, '', trace);
      var files = [];
      for (var i = 0; i < candidates.length; i++) {
        var df = toDownloadFile(candidates[i]);
        if (df) files.push(df);
      }

      var elapsed = Date.now() - t0;
      var label = (track.artist ? (track.artist + ' - ') : '') + track.title;

      if (files.length) {
        recordResolvedTrackInfo(track, candidates[0]);
        var dlHit = label + ' (' + reqQual + ') -> ' + files[0].provider + ' [' + files[0].format + '] (' + elapsed + 'ms)';
        appendDiag('download', dlHit);
        log('download: ' + dlHit);
        return files;
      }

      var dlMiss = label + ' (' + reqQual + ') [' + (trace.length ? trace.join(', ') : 'nessuna fonte') + ']';
      appendDiag('dl-miss', dlMiss);
      log('download-miss (' + elapsed + 'ms): ' + dlMiss);
      return hostHas('results') ? { outcome: 'not-found' } : [];
    });
  });

  })();
